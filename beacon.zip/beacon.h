#pragma once

#include <stddef.h>
#include <stdint.h>

// Stores the finished beacon packet. Interval 0 stops beacons.
void beaconSet(const uint8_t* packet, size_t len, uint16_t intervalS);

// Call on every pass of loop().
void beaconService();

// Call right after loraTxDone() returns true. True if that send was a beacon,
// which has no TX_RESULT.
bool beaconTxFinished();

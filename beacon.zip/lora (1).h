#pragma once

#include <stddef.h>
#include <stdint.h>

bool loraBegin();
void loraSetPower(uint8_t preset);

// Only one send can be in flight. Returns false if busy or the length is out of range.
bool loraSend(const uint8_t* packet, size_t len);

// True once per finished send. result is a TxResult.
bool loraTxDone(uint8_t& result);

// buf must hold LORA_MAX_PAYLOAD bytes. Returns the packet length, or 0 if nothing arrived.
size_t loraReceive(uint8_t* buf, int8_t& rssi, int8_t& snr);

// Call on every pass of loop().
void loraService();

#pragma once

#include <stddef.h>
#include <stdint.h>

void linkBegin();

// Pulls the radio's enable pin low. The pulse ends by itself from linkPoll().
void linkResetRadio();

// Sends one frame. extra is appended to the payload, so a header and a packet need no copy.
void linkSend(uint8_t type, const void* payload, size_t len, const void* extra = nullptr, size_t extraLen = 0);

// Returns true once per complete frame. payload must hold LINK_MAX_PAYLOAD bytes.
// Call on every pass of loop().
bool linkPoll(uint8_t& type, uint8_t* payload, uint16_t& len);

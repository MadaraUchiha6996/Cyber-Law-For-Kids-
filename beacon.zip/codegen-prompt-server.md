# PROMPT: Off-Grid Radio Server on Raspberry Pi 3B (paste into any AI)

You are a senior Python engineer. Write the **relay server** of an off-grid LoRa radio network. It runs on a Raspberry Pi 3B. Build it in the phases at the end, ONE file per reply, and wait for me to say "next".

## CODE RULES
1. Write like an experienced developer writing by hand. Plain names, short functions, no decorative banners, no emoji, no generic filler.
2. Before keeping any line, ask: "Why does this line exist? What breaks if I delete it?" If nothing breaks, delete it.
3. No dead code, unused variables, unused imports, unused functions, or commented-out code.
4. No features, options, or abstractions that the spec does not ask for.
5. Comments only where the reason is not obvious. Never comment what the line plainly does.
6. Every function fully implemented. No TODO, placeholder, or pseudo-code.
7. Never block the asyncio event loop. No time.sleep, no blocking file or serial calls inside coroutines.
8. Handle failures that really happen (serial unplugged, bad packet, storage full, lost link, corrupt database). No handling for things that cannot happen.
9. All paths, timings, sizes, limits and keys live in config.py. No magic numbers elsewhere.
10. Before replying, re-read your code once, delete every line that fails rule 2, then output only the cleaned code.
11. Output format: file name, then code block. No explanations or summaries.

## PLATFORM
Raspberry Pi 3B, Raspberry Pi OS Lite, Python 3.11 or newer, asyncio. Libraries: pyserial (serial link), cryptography (X25519, HKDF, ChaCha20-Poly1305), sqlite3 (storage), websockets (internet bridge). Do not use others unless necessary, and say why in one line. Runs as a systemd service that restarts on failure.

## RADIO LINK
The Pi has no LoRa chip of its own. It talks to a **radio ESP** (Heltec HT-CT62, ESP32-C3 + SX1262) over a serial port (`SERIAL_PORT` in config.py, for example /dev/ttyUSB0, 460800 baud). That radio ESP runs the SAME radio firmware as the handheld devices, so write NO radio code and no LoRa code. The Pi speaks the device project's UART frame exactly:
`0xA5 | len(2, little endian) | type(1) | payload | crc16(2)`. Reject bad CRC, resync on 0xA5. The radio ESP prints boot text on the same serial line, so ignore every byte until a valid frame arrives, then wait for READY. An optional GPIO pin (`RADIO_EN_GPIO`, -1 = none) resets the radio.
Main to radio: SEND_PACKET, SET_POWER(preset), SET_BEACON(payload with lat/lon, interval), SCAN_SERVERS, CONNECT(serverId), SLEEP.
Radio to main: READY, RX_PACKET (data + rssi + snr), TX_RESULT(msgId, ok/fail), SERVER_LIST, LINK_STATE.
The server's own position is fixed: `SERVER_LAT` and `SERVER_LON` in config.py go into the server beacon so devices can point to it.
Packet formats, types and crypto come from `protocol.md` of the device project. Implement them in `protocol.py` byte for byte. Do not invent fields.

## ROLE
The server is a **middleman that bounces messages**. Devices never talk directly to each other: sender -> server -> receiver. The server stores messages until the receiver asks for them.

## BOOT AND AUTO-CONNECT
1. On start: open the database, load the registry and queues, open the serial port, wait for READY, set the beacon.
2. Server beacon every 60 s with jitter (interval in config.py). Right after start also broadcast one SERVER_HELLO so nearby devices answer with a beacon after a random delay.
3. Every device beacons constantly. When the server hears a beacon from a known device it connects automatically (JOIN_ACK), marks it online, and records signal strength and last position. Unknown devices get an automatic JOIN and a registry entry on first contact.
4. A device not heard for 3 beacon intervals is marked offline. Its messages stay queued.
5. Reply to DEVLIST_REQ with the list of online devices (name, id, last position age, missing flag).

## STORE AND FORWARD (SQLite on the SD card)
- **Text:** queue per recipient. Deliver when the recipient is online and asks, or push when it comes online. Remove after ACK. Expire after a TTL in config.py.
- **Voice:** store the fragments as received. Each device holds **one** voice note. If the device's slot is full, keep the voice note queued and do not push it. Deliver only after the device sends VOICE_SLOT_FREE or VOICE_REQ. **Text delivery must never wait on voice.** One voice note per recipient waiting at most (oldest wins or newest wins, config option).
- Voice arrives as very small fragments (payload `VOICE_FRAG_BYTES`, default 48 bytes, about 19 per 10 s note). Store and forward them as they are, never decode or re-encode, answer fragment retry requests by index, resume interrupted transfers by fragment index.
- Delivery receipts back to the sender: at server, delivered, failed.
- Airtime: send one packet at a time and wait for TX_RESULT. ACKs and text go before voice fragments.
- Cap total database size in config.py. When full, drop the oldest expired items first. Batch writes so the SD card is not written constantly (SQLite WAL mode).

## MISSING DEVICE DETECTION
- Track for every device: last time ANY valid packet was received from it (beacon, ACK, message), last position, and last ACK or read time for messages delivered to it.
- Flag the device **MISSING** when both are older than `MISSING_AFTER_DAYS` in config.py (default 3): no valid packet of any kind AND no response to queued text or voice. A device that still beacons but never responds is flagged `UNRESPONSIVE` (separate flag).
- Store the last known position and time with the flag. Include the flag, last-seen time and last position in DEVLIST replies.
- When someone sends to a MISSING device, return a delivery receipt of "recipient missing" in addition to queuing the message.
- Clear the flag automatically on the next valid packet from that device. Messages for a missing device stay queued until their normal TTL.

## ENCRYPTION AND WHAT THE SERVER CAN CHECK
- Device to server link: a **hop key** (derived at JOIN, X25519 + HKDF) authenticates every packet. Drop anything that fails authentication.
- Device to device content: **end-to-end encrypted** (X25519 + ChaCha20-Poly1305). The server cannot read it and must not try.
- Because content is opaque, "virus checking" is done on everything the server can actually see. Validation pipeline for every packet, in this order, drop and log on the first failure:
  1. Version and type are known.
  2. Length fits the type and the LoRa limit.
  3. Hop-key authentication tag is valid.
  4. Sender is registered and not blocked.
  5. Replay check (msgId window + timestamp).
  6. Rate limit per device (config.py).
  7. Fragment sanity: index < total, total within limit, no duplicates, no gaps on completion.
  8. Voice sanity: total size matches at most 10 s of the codec rate. Text size under the max.
  9. Destination exists.
- Repeat offenders are blocked for a period. Everything dropped is logged with the reason.
- Never forward a message that failed validation.

## INTERNET BRIDGE
A WebSocket server over TLS (certificate paths in config.py). Devices in internet mode connect with their device id and a hop-key authenticated first message, and use the same packet format. Same validation, same queues, same encryption. How the Pi is reachable from outside (port forward or tunnel) is outside this program.

## RELIABILITY
systemd unit with Restart=always, graceful shutdown that flushes the database, atomic database transactions, log rotation, log levels, clock from the system (NTP).

## BUILD ORDER (one file per reply, wait for "next")
1. config.py
2. protocol.py (from the device project's protocol.md)
3. radio_link.py (serial frames, CRC, resync, READY, SET_BEACON, SEND_PACKET)
4. db.py (schema, text and voice queues)
5. registry.py (devices, online state, missing flags, blocking)
6. validator.py (pipeline above)
7. router.py (joins, device list, forwarding, receipts)
8. bridge.py (internet)
9. main.py and the systemd unit file

Start with step 1 now. Do not write anything else until I say "next".

#pragma once

#if !defined(BOARD_MAIN_S3) && !defined(BOARD_HT_CT62) && !defined(BOARD_HELTEC_V3)
#error "Define BOARD_MAIN_S3, BOARD_HT_CT62 or BOARD_HELTEC_V3 in build_flags"
#endif

// Same on every unit. A different value here and the units cannot hear each other.
// India allows 200 kHz per carrier at 865 to 867 MHz, so 125 kHz is the only bandwidth used.
#define LORA_FREQ_MHZ           865.5f
#define LORA_BW_KHZ             125.0f
#define NETWORK_SF              9
#define LORA_CR_DENOM           5
#define LORA_PREAMBLE_SYMBOLS   8
#define LORA_CRC_BYTES          2
#define LORA_SYNC_WORD          0x5A
#define LORA_MAX_PAYLOAD        255

#define TX_POWER_SHORT_DBM      10
#define TX_POWER_MEDIUM_DBM     14
#define TX_POWER_LONG_DBM       17
#define TX_POWER_MAX_DBM        22

// Set ANTENNA_GAIN_DBI to the real gain of the antenna on J11.
// The radio clamps TX power so power + gain - loss never exceeds the limit.
#define ANTENNA_GAIN_DBI        3
#define EIRP_LIMIT_DBM          36
#define FEEDLINE_LOSS_DB        2

#define LBT_BACKOFF_MIN_MS      30
#define LBT_BACKOFF_MAX_MS      400
#define LBT_MAX_ATTEMPTS        6

#define ACK_TIMEOUT_MS          3000
#define VOICE_ACK_TIMEOUT_MS    6000
#define SEND_RETRY_MAX          3
#define RETRY_BACKOFF_MS        1500
#define REASSEMBLY_TIMEOUT_MS   30000
#define HELLO_REPLY_MAX_MS      3000

#define BEACON_INTERVAL_S       60
#define BEACON_JITTER_PCT       20
#define SERVER_LOST_BEACONS     3

// Main ESP <-> radio ESP link
#define LINK_BAUD               460800
#define LINK_MAX_PAYLOAD        288
#define LINK_FRAME_TIMEOUT_MS   50
#define RADIO_READY_TIMEOUT_MS  3000
#define RADIO_RESET_PULSE_MS    20

// Voice
#define AUDIO_SAMPLE_RATE_HZ    8000
#define VOICE_MAX_S             10
#define VOICE_FRAG_BYTES        48
#define VOICE_USE_1200          0
#define VOICE_FRAME_MS          40
#if VOICE_USE_1200
#define VOICE_FRAME_BITS        48
#else
#define VOICE_FRAME_BITS        28
#endif
#define VOICE_MAX_BYTES         ((VOICE_MAX_S * 1000 / VOICE_FRAME_MS * VOICE_FRAME_BITS + 7) / 8)

#if defined(BOARD_HT_CT62)
// SX1262 wiring inside the module, from the Heltec HT-CT62 Rev 1.1 datasheet (pin table)
#define SX_NSS                  8
#define SX_SCK                  10
#define SX_MOSI                 7
#define SX_MISO                 6
#define SX_RST                  5
#define SX_BUSY                 4
#define SX_DIO1                 3
// The 32 MHz oscillator is powered from 3V3 (see the schematic), so the SX1262 does not drive it.
#define SX_TCXO_VOLTS           0.0f
#endif

#if defined(BOARD_HELTEC_V3)
// Heltec WiFi LoRa 32 V3 (Pi side radio). The link to the Pi is the USB-C port, Serial at LINK_BAUD.
#define SX_NSS                  8
#define SX_SCK                  9
#define SX_MOSI                 10
#define SX_MISO                 11
#define SX_RST                  12
#define SX_BUSY                 13
#define SX_DIO1                 14
#define SX_TCXO_VOLTS           1.8f
#endif

#if defined(BOARD_MAIN_S3)
#define I2C_SDA_PIN             7
#define I2C_SCL_PIN             8
#define I2C_HZ                  100000
#define OLED_ADDR               0x3C
#define IMU_ADDR                0x69
#define IMU_INT_PIN             9

#define BTN_UP_PIN              21
#define BTN_SELECT_PIN          14
#define BTN_BACK_PIN            10
#define BTN_DEBOUNCE_MS         25
#define BTN_SEND_HOLD_MS        2000
#define BTN_HOME_HOLD_MS        1000
#define SOS_HOLD_MS             3000

#define AMP_DIN_PIN             4
#define AMP_BCLK_PIN            5
#define AMP_LRCLK_PIN           6
#define AMP_I2S_PORT            0

#define MIC_BCLK_PIN            12
#define MIC_WS_PIN              11
#define MIC_DIN_PIN             13
#define MIC_I2S_PORT            1

#define GPS_RX_PIN              17
#define GPS_TX_PIN              18
#define GPS_BAUD                9600
#define GPS_UART_PORT           1
#define LOCAL_UTC_OFFSET_MIN    330

#define LINK_TX_PIN             33
#define LINK_RX_PIN             34
#define LINK_UART_PORT          2
#define RADIO_EN_PIN            2
#endif

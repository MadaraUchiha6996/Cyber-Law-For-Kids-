#include <Arduino.h>
#include "protocol.h"
#include "lora.h"
#include "beacon.h"
#include "uart_link.h"

static bool loraOk;
static uint8_t pendingHandle;

static void reportTx(uint8_t handle, uint8_t result) {
  LinkTxResult report = { handle, result };
  linkSend(LINK_MSG_TX_RESULT, &report, sizeof(report));
}

static void handleFrame(uint8_t type, const uint8_t* payload, uint16_t len) {
  if (type == LINK_MSG_SEND_PACKET) {
    if (len < sizeof(LinkSendInfo)) return;
    uint8_t handle = ((const LinkSendInfo*)payload)->handle;
    if (loraOk && loraSend(payload + sizeof(LinkSendInfo), len - sizeof(LinkSendInfo))) {
      pendingHandle = handle;
    } else {
      reportTx(handle, TX_RADIO_ERROR);
    }
    return;
  }
  if (!loraOk) return;
  if (type == LINK_MSG_SET_POWER && len >= 1) {
    loraSetPower(payload[0]);
  } else if (type == LINK_MSG_SET_BEACON && len >= sizeof(LinkBeaconInfo)) {
    beaconSet(payload + sizeof(LinkBeaconInfo), len - sizeof(LinkBeaconInfo),
              ((const LinkBeaconInfo*)payload)->intervalS);
  }
}

void setup() {
  linkBegin();
  loraOk = loraBegin();
  uint8_t status = loraOk ? READY_OK : READY_RADIO_FAILED;
  linkSend(LINK_MSG_READY, &status, sizeof(status));
}

// The order matters: a finished send is collected before the host can start the next one,
// so a beacon's result is never mistaken for a host packet's.
void loop() {
  loraService();

  uint8_t result;
  if (loraTxDone(result) && !beaconTxFinished()) reportTx(pendingHandle, result);

  uint8_t packet[LORA_MAX_PAYLOAD];
  int8_t rssi, snr;
  size_t packetLen = loraReceive(packet, rssi, snr);
  if (packetLen) {
    LinkRxInfo info = { rssi, snr };
    linkSend(LINK_MSG_RX_PACKET, &info, sizeof(info), packet, packetLen);
  }

  uint8_t type;
  uint8_t payload[LINK_MAX_PAYLOAD];
  uint16_t len;
  if (linkPoll(type, payload, len)) handleFrame(type, payload, len);

  beaconService();
}

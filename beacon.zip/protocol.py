import binascii
import hashlib
import struct
from dataclasses import dataclass
from enum import IntEnum, IntFlag

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from config import VOICE_FRAG_BYTES, VOICE_MAX_BYTES, VOICE_USE_1200

# All multi-byte fields are little endian. See shared/protocol.md.

# UART link
LINK_START_BYTE = 0xA5
LINK_OVERHEAD_BYTES = 6
LINK_CRC_INIT = 0xFFFF


class LinkMsg(IntEnum):
    SEND_PACKET = 0x01
    SET_POWER = 0x02
    SET_BEACON = 0x03
    READY = 0x81
    RX_PACKET = 0x82
    TX_RESULT = 0x83


class TxResult(IntEnum):
    OK = 0
    CHANNEL_BUSY = 1
    RADIO_ERROR = 2


class ReadyStatus(IntEnum):
    OK = 0
    RADIO_FAILED = 1


LINK_SEND_INFO = struct.Struct("<B")
LINK_TX_RESULT = struct.Struct("<BB")
LINK_RX_INFO = struct.Struct("<bb")
LINK_BEACON_INFO = struct.Struct("<H")

# LoRa packet
PROTOCOL_VERSION = 1
PKT_VERSION_SHIFT = 4
PKT_TYPE_MASK = 0x0F
LORA_MAX_PAYLOAD = 255
ID_NONE = 0x0000
ID_BROADCAST = 0xFFFF
TAG_BYTES = 16
KEY_BYTES = 32
PUBKEY_BYTES = 32
E2E_NONCE_BYTES = 12
JOIN_NONCE_BYTES = 8
NAME_BYTES = 12
HOP_KEY_INFO = b"offgrid-hop-v1"
MSG_ID_LIMIT = 0xFF00
REPLAY_WINDOW = 64
TEXT_MAX_BYTES = 100
E2E_OVERHEAD_BYTES = E2E_NONCE_BYTES + TAG_BYTES
POSITION_SCALE = 10_000_000


class PacketType(IntEnum):
    BEACON = 1
    SERVER_HELLO = 2
    JOIN = 3
    JOIN_ACK = 4
    DEVLIST_REQ = 5
    DEVLIST = 6
    TEXT = 7
    VOICE_META = 8
    VOICE_FRAG = 9
    VOICE_REQ = 10
    VOICE_SLOT_FREE = 11
    ACK = 12
    RECEIPT = 13
    SOS = 14


class BeaconFlag(IntFlag):
    SERVER = 0x01
    NO_FIX = 0x02


class DevFlag(IntFlag):
    ONLINE = 0x01
    MISSING = 0x02
    UNRESPONSIVE = 0x04
    NO_FIX = 0x08


class ReceiptStatus(IntEnum):
    DELIVERED = 1
    READ = 2
    RECIPIENT_MISSING = 3
    FAILED_NO_DEST = 4
    FAILED_EXPIRED = 5
    FAILED_REFUSED = 6


class VoiceCodec(IntEnum):
    CODEC_700C = 0
    CODEC_1200 = 1


VOICE_CODEC_ID = VoiceCodec.CODEC_1200 if VOICE_USE_1200 else VoiceCodec.CODEC_700C

HEADER = struct.Struct("<BHHHBBB")
BEACON = struct.Struct(f"<Bii{NAME_BYTES}s")
JOIN = struct.Struct(f"<{PUBKEY_BYTES}s{JOIN_NONCE_BYTES}s{NAME_BYTES}s")
JOIN_ACK = struct.Struct(f"<{PUBKEY_BYTES}s{JOIN_NONCE_BYTES}s")
DEV_ENTRY = struct.Struct(f"<HBiiI{NAME_BYTES}s{PUBKEY_BYTES}s")
VOICE_META = struct.Struct("<HB")
VOICE_REQ = struct.Struct("<H")
ACK = struct.Struct("<H")
RECEIPT = struct.Struct("<HB")
SOS = struct.Struct("<ii")

HEADER_BYTES = HEADER.size
PKT_MAX_PAYLOAD = LORA_MAX_PAYLOAD - HEADER_BYTES - TAG_BYTES
DEVLIST_PER_PACKET = PKT_MAX_PAYLOAD // DEV_ENTRY.size


def fragment_count(blob_bytes: int) -> int:
    return (blob_bytes + VOICE_FRAG_BYTES - 1) // VOICE_FRAG_BYTES


VOICE_BLOB_MAX = VOICE_MAX_BYTES + E2E_OVERHEAD_BYTES
VOICE_MAX_FRAGS = fragment_count(VOICE_BLOB_MAX)
VOICE_BITMAP_BYTES = (VOICE_MAX_FRAGS + 7) // 8

# Payload sizes each type may have (section 3.2 of protocol.md).
PAYLOAD_LENGTHS = {
    PacketType.BEACON: {BEACON.size},
    PacketType.SERVER_HELLO: {0},
    PacketType.JOIN: {JOIN.size},
    PacketType.JOIN_ACK: {JOIN_ACK.size},
    PacketType.DEVLIST_REQ: {0},
    PacketType.DEVLIST: range(DEV_ENTRY.size, DEVLIST_PER_PACKET * DEV_ENTRY.size + 1, DEV_ENTRY.size),
    PacketType.TEXT: range(E2E_OVERHEAD_BYTES + 1, E2E_OVERHEAD_BYTES + TEXT_MAX_BYTES + 1),
    PacketType.VOICE_META: {VOICE_META.size},
    PacketType.VOICE_FRAG: range(1, VOICE_FRAG_BYTES + 1),
    PacketType.VOICE_REQ: {VOICE_REQ.size},
    PacketType.VOICE_SLOT_FREE: {0},
    PacketType.ACK: {ACK.size, ACK.size + VOICE_BITMAP_BYTES},
    PacketType.RECEIPT: {RECEIPT.size},
    PacketType.SOS: {SOS.size},
}


class PacketError(Exception):
    pass


@dataclass(frozen=True)
class Packet:
    type: PacketType
    src: int
    dst: int
    msg_id: int
    frag_idx: int
    frag_total: int
    payload: bytes
    tag: bytes
    signed: bytes  # header and payload, the data the tag covers


def crc16(data: bytes) -> int:
    return binascii.crc_hqx(data, LINK_CRC_INIT)


def encode_frame(msg_type: int, payload: bytes) -> bytes:
    body = struct.pack("<HB", len(payload), msg_type) + payload
    return bytes([LINK_START_BYTE]) + body + struct.pack("<H", crc16(body))


def has_tag(packet_type: int) -> bool:
    return packet_type not in (PacketType.BEACON, PacketType.SERVER_HELLO, PacketType.JOIN)


def hop_nonce(src: int, msg_id: int, frag_idx: int, packet_type: int) -> bytes:
    return struct.pack("<HHBB6x", src, msg_id, frag_idx, packet_type)


def compute_tag(hop_key: bytes, signed: bytes, nonce: bytes) -> bytes:
    return ChaCha20Poly1305(hop_key).encrypt(nonce, b"", signed)


def verify_tag(hop_key: bytes, packet: Packet) -> bool:
    nonce = hop_nonce(packet.src, packet.msg_id, packet.frag_idx, packet.type)
    try:
        ChaCha20Poly1305(hop_key).decrypt(nonce, packet.tag, packet.signed)
    except InvalidTag:
        return False
    return True


def build_packet(packet_type: PacketType, src: int, dst: int, msg_id: int, payload: bytes = b"",
                 hop_key: bytes | None = None, frag_idx: int = 0, frag_total: int = 1) -> bytes:
    ver_type = (PROTOCOL_VERSION << PKT_VERSION_SHIFT) | packet_type
    signed = HEADER.pack(ver_type, src, dst, msg_id, frag_idx, frag_total, len(payload)) + payload
    if not has_tag(packet_type):
        return signed
    return signed + compute_tag(hop_key, signed, hop_nonce(src, msg_id, frag_idx, packet_type))


def parse_packet(data: bytes) -> Packet:
    if len(data) < HEADER_BYTES:
        raise PacketError("too short")
    ver_type, src, dst, msg_id, frag_idx, frag_total, length = HEADER.unpack_from(data)
    if ver_type >> PKT_VERSION_SHIFT != PROTOCOL_VERSION:
        raise PacketError("unknown version")
    try:
        packet_type = PacketType(ver_type & PKT_TYPE_MASK)
    except ValueError:
        raise PacketError("unknown type") from None
    end = HEADER_BYTES + length
    if len(data) != end + (TAG_BYTES if has_tag(packet_type) else 0):
        raise PacketError("length mismatch")
    return Packet(packet_type, src, dst, msg_id, frag_idx, frag_total,
                  data[HEADER_BYTES:end], data[end:], data[:end])


def device_id(public_key: bytes) -> int:
    return int.from_bytes(hashlib.sha256(public_key).digest()[:2], "little")


# Raises ValueError if peer_public is not a usable X25519 key.
def derive_hop_key(own_private: X25519PrivateKey, peer_public: bytes,
                   device_nonce: bytes, server_nonce: bytes) -> bytes:
    shared = own_private.exchange(X25519PublicKey.from_public_bytes(peer_public))
    return HKDF(algorithm=hashes.SHA256(), length=KEY_BYTES,
                salt=device_nonce + server_nonce, info=HOP_KEY_INFO).derive(shared)


def make_bitmap(received) -> bytes:
    bitmap = bytearray(VOICE_BITMAP_BYTES)
    for n in received:
        bitmap[n // 8] |= 1 << (n % 8)
    return bytes(bitmap)


def missing_fragments(bitmap: bytes, total: int) -> list[int]:
    return [n for n in range(total) if not (bitmap[n // 8] >> (n % 8)) & 1]


def unpack_name(raw: bytes) -> str:
    return raw.rstrip(b"\0").decode("ascii", errors="replace")


def to_e7(degrees: float) -> int:
    return round(degrees * POSITION_SCALE)

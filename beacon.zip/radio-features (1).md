# Off-Grid Multimedia Radio: Feature List

## 1. Hardware split (matches your KiCad board)

| Part | Chip | Job |
|---|---|---|
| **Main ESP** (U3) | ESP32-S3FH4R2 | Brain: OLED UI, buttons, voice record and playback, compass, GPS reading (J5), encryption, message storage, WiFi/internet mode, settings, battery % |
| **Radio ESP** (U7) | Heltec HT-CT62 (ESP32-C3 + SX1262 LoRa) | Transfer only: LoRa send/receive, packet splitting, ACK/retry, beacons |
| **Link** | UART between U3 and U7 | Framed binary packets, main = commander, radio = worker |

Other chips already on your board: MAX98357A + speaker (voice playback), ICM-20948 (compass), BQ24074 (charging), TPS63001 (3.3 V). The microphone goes on a connector socket, so make sure it is an I2S MEMS mic (e.g. INMP441), because the code reads it over I2S.

**Missing from the board right now (needed for the features below):**
- GPS module (e.g. ATGM336H or NEO-6M): it plugs into J5, which is wired to the **main ESP** (UART1), not the radio ESP. The main ESP reads the GPS and hands the position to the radio for beacons. See `hardware-map.md` for the full pin map and the board fixes.
- OLED (SSD1306 128x64, I2C) plugs into J4 (pin order GND, 3V3, SCL, SDA, check that your module has the same order). The 3 UI buttons are SW5 (B1), SW3 (B2), SW4 (B3), already on the board. The OLED can share the I2C bus with the IMU (different addresses).
- Battery voltage divider into an ESP32-S3 ADC pin. The BQ24074 has no fuel gauge, so battery % has to be estimated from voltage. Your battery with a built-in protection circuit handles over-discharge and short-circuit cutoff by itself, but it does not report its level, so the divider is still needed.

## 2. Controls (3 buttons)

| Button | Press | Action |
|---|---|---|
| B1 (top) | short | Scroll up. At the top it wraps to the bottom |
| B2 (middle) | short | Select / confirm. Also start/stop voice recording |
| B2 (middle) | long (about 2 s) | Send message |
| B3 (back) | short | Back one step (in text entry: delete last letter, and back if empty) |
| B3 (back) | long | Straight to Home |

The same three buttons work on every screen, so nothing needs to be re-learned. The BOOT and RESET buttons on the board (SW1, SW2) are hardware-only: they flash and restart the ESPs and are not part of the UI.

## 3. Home menu (5 options)

1. Send Msg
2. Inbox
3. GPS
4. Compass
5. Settings

A status bar is always visible: battery, LoRa link strength, GPS fix, internet icon, unread count.

## 4. Send Msg

1. **Connect to server**: shows a list of servers heard nearby (from their beacons), with signal strength. Pick one and the device connects.
2. **Device list**: all ESPs connected to that server, with online/last-seen state. A device the server has flagged as **MISSING** shows a MISSING tag with its last-seen time and last known position. Pick one.
3. **Choose type**: Voice note or Text.

### Voice note
- B2 starts recording, maximum **10 s**, auto-stops at 10 s (B2 again stops early). A countdown bar is shown.
- After recording: B1 sends, B2 plays it back, B3 discards.
- On send: popup **"Msg sent!!"**, then back to the Voice/Text choice.
- Audio is compressed with Codec2 at 700 bps, so a 10 s note is only about 875 bytes. It is then cut into very small packets (about 48 bytes each, roughly 19 packets) so each one is a short LoRa message that is quick to send and cheap to retry. The receiver rebuilds the note, and missing packets are re-requested by number.

### Text
- Preset list: "I am safe", "I need help", "Come to my location", "On my way", "Low battery", "All good here" (you can add more).
- Last item: **Custom message**.
- Custom message screen shows the letters as a vertical list, and the message line on top:
  ```
  a| hello
  b|
  c|
  d|
  ```
  B1 scrolls the letter list (wraps), B2 adds the highlighted letter. The list also has Space, Backspace, digits, punctuation and Send. B3 short deletes, B3 long goes home. Holding B2 sends.
- On send: popup **"Msg sent!!"**.

### Incoming
- Popup **"Msg is here !!"** on any new message, with a buzzer or LED if fitted.

## 5. Inbox

- List of messages, newest first: date, time, sender, first few words.
- Text messages open fully on select.
- Top row of the list toggles **Text / Voice**.
- Voice entries show date and time. Selecting one **requests** the note from the server, then plays it.
- **One voice slot per device.** If a new voice note arrives while the slot is full, the server holds it. It is delivered only after you delete the old one. Text keeps flowing normally the whole time.
- Delete (long B2 on an item), mark read, auto-delete oldest when storage is full.

## 6. GPS

- First row: GPS **ON / OFF** toggle (saves battery).
- Then the list: server and every ESP, with last known position age.
- Select one: compass screen with an arrow pointing to that device, plus **approximate distance** (metres or km).
- Uses your own GPS fix and the positions other devices share in their beacons, and the ICM-20948 heading so the arrow turns as you turn.
- Shows "no fix" or "no position from that device" when data is missing.

## 7. Compass

- Heading in degrees plus N/E/S/W, using the ICM-20948 magnetometer with tilt compensation.
- Calibration screen (wave the device in a figure 8), calibration saved to flash.
- Shows true north offset only when GPS has a fix.

## 8. Settings

1. **Screen timeout**: 1 min, 3 min, 5 min, 7 min, Never.
2. **LoRa range**: Short / Medium / Long / Max. This changes transmit power (+10, +14, +17, +22 dBm). The spreading factor is fixed for the whole network (default SF9), because a device on a different spreading factor could not hear the others.
3. **Battery**: percentage and charging state.
4. **Internet**: scan WiFi, pick network, password entry with the same letter-list keyboard. When connected, messages go through the internet to the server, giving huge range. Falls back to LoRa automatically when WiFi drops.
5. **About device**: name/ID, firmware version, chip details, LoRa frequency, free storage, uptime, GPS status, battery health.

## 9. Features you did not list (recommended)

Keep:
- **Delivery ticks**: sent, delivered to server, delivered to device, read.
- **ACK and auto-retry** for every message, with a "failed, retry?" popup.
- **SOS**: hold all three buttons for 3 s to broadcast an emergency message with your GPS position to every device.
- **Time from GPS**: the inbox needs date and time off-grid, so set the clock from GPS time.
- **Device name**: set it once, shown instead of an ID.
- **Signal strength** (RSSI/SNR) for each server and device in lists.
- **Low-battery warning** popup at 20% and 10%, and a safe shutdown at about 3%.
- **Speaker volume** setting and mute.
- **Sleep mode**: screen off, radio listening on duty cycle, wake on button or incoming packet.
- **Storage limits** with auto-delete oldest.
- **Encryption indicator** (lock icon) on every message.

Optional later:
- Device PIN lock.
- OTA firmware update over WiFi.
- Group broadcast message to all devices.
- Flashlight LED, factory reset, backup of settings.

## 10. Reality checks

- **Voice over LoRa is slow.** At the default SF9 and 125 kHz, a 10 s note (about 19 small packets plus one ACK) takes roughly 10 to 15 seconds to send. Text takes about a second.
- **Bandwidth is capped at 125 kHz** to stay inside India's 200 kHz limit for 865 to 867 MHz.
- **Frequency:** use the 865 to 867 MHz band for India, and check that your HT-CT62 variant supports it.
- **Battery %** will be an estimate from voltage, close but not exact.
- **Distance** from GPS is approximate, it gets worse under trees or indoors.

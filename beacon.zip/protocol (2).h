#pragma once

#include <stdint.h>
#include "config.h"

// All multi-byte fields are little endian. Must match protocol.py.

#define LINK_START_BYTE         0xA5
#define LINK_OVERHEAD_BYTES     6
#define LINK_CRC_INIT           0xFFFF
#define LINK_CRC_POLY           0x1021

#define LINK_MSG_SEND_PACKET    0x01
#define LINK_MSG_SET_POWER      0x02
#define LINK_MSG_SET_BEACON     0x03
#define LINK_MSG_READY          0x81
#define LINK_MSG_RX_PACKET      0x82
#define LINK_MSG_TX_RESULT      0x83

#define READY_OK                0
#define READY_RADIO_FAILED      1

#define TX_OK                   0
#define TX_CHANNEL_BUSY         1
#define TX_RADIO_ERROR          2

#define POWER_MAX               3

// Size of the LoRa packet header: type, src, dst, msg_id, frag_idx, frag_total, length.
#define HEADER_BYTES            10

struct __attribute__((packed)) LinkSendInfo { uint8_t handle; };
struct __attribute__((packed)) LinkTxResult { uint8_t handle; uint8_t result; };
struct __attribute__((packed)) LinkRxInfo { int8_t rssi; int8_t snr; };
struct __attribute__((packed)) LinkBeaconInfo { uint16_t intervalS; };

#define PROTOCOL_VERSION        1
#define PKT_VERSION_SHIFT       4
#define PKT_TYPE_MASK           0x0F

#define ID_NONE                 0x0000
#define ID_BROADCAST            0xFFFF
#define MSG_ID_LIMIT            0xFF00
#define REPLAY_WINDOW           64

#define TAG_BYTES               16
#define KEY_BYTES               32
#define PUBKEY_BYTES            32
#define E2E_NONCE_BYTES         12
#define JOIN_NONCE_BYTES        8
#define NAME_BYTES              12
#define HOP_KEY_INFO            "offgrid-hop-v1"
#define E2E_KEY_INFO            "offgrid-e2e-v1"
#define POSITION_SCALE          10000000

#define PKT_BEACON              1
#define PKT_SERVER_HELLO        2
#define PKT_JOIN                3
#define PKT_JOIN_ACK            4
#define PKT_DEVLIST_REQ         5
#define PKT_DEVLIST             6
#define PKT_TEXT                7
#define PKT_VOICE_META          8
#define PKT_VOICE_FRAG          9
#define PKT_VOICE_REQ           10
#define PKT_VOICE_SLOT_FREE     11
#define PKT_ACK                 12
#define PKT_RECEIPT             13
#define PKT_SOS                 14

#define PKT_MAX_PAYLOAD         (LORA_MAX_PAYLOAD - HEADER_BYTES - TAG_BYTES)

#define BEACON_FLAG_SERVER      0x01
#define BEACON_FLAG_NO_FIX      0x02

#define DEV_FLAG_ONLINE         0x01
#define DEV_FLAG_MISSING        0x02
#define DEV_FLAG_UNRESPONSIVE   0x04
#define DEV_FLAG_NO_FIX         0x08

#define RECEIPT_DELIVERED       1
#define RECEIPT_READ            2
#define RECEIPT_RECIPIENT_MISSING 3
#define RECEIPT_FAILED_NO_DEST  4
#define RECEIPT_FAILED_EXPIRED  5
#define RECEIPT_FAILED_REFUSED  6

// TEXT payload is the end-to-end blob: nonce, ciphertext, tag.
#define TEXT_MAX_BYTES          100
#define E2E_OVERHEAD_BYTES      (E2E_NONCE_BYTES + TAG_BYTES)

#define CODEC_700C              0
#define CODEC_1200              1
#define VOICE_CODEC_ID          (VOICE_USE_1200 ? CODEC_1200 : CODEC_700C)
#define VOICE_BLOB_MAX          (VOICE_MAX_BYTES + E2E_OVERHEAD_BYTES)
#define VOICE_MAX_FRAGS         ((VOICE_BLOB_MAX + VOICE_FRAG_BYTES - 1) / VOICE_FRAG_BYTES)
#define VOICE_BITMAP_BYTES      ((VOICE_MAX_FRAGS + 7) / 8)

struct __attribute__((packed)) PacketHeader {
  uint8_t verType;
  uint16_t src;
  uint16_t dst;
  uint16_t msgId;
  uint8_t fragIdx;
  uint8_t fragTotal;
  uint8_t len;
};

static_assert(sizeof(PacketHeader) == HEADER_BYTES, "PacketHeader must match HEADER_BYTES");

struct __attribute__((packed)) BeaconPayload {
  uint8_t flags;
  int32_t lat;
  int32_t lon;
  char name[NAME_BYTES];
};

struct __attribute__((packed)) JoinPayload {
  uint8_t pubkey[PUBKEY_BYTES];
  uint8_t nonce[JOIN_NONCE_BYTES];
  char name[NAME_BYTES];
};

struct __attribute__((packed)) JoinAckPayload {
  uint8_t pubkey[PUBKEY_BYTES];
  uint8_t nonce[JOIN_NONCE_BYTES];
};

struct __attribute__((packed)) DevEntry {
  uint16_t id;
  uint8_t flags;
  int32_t lat;
  int32_t lon;
  uint32_t ageS;
  char name[NAME_BYTES];
  uint8_t pubkey[PUBKEY_BYTES];
};

struct __attribute__((packed)) VoiceMetaPayload { uint16_t totalFrags; uint8_t codec; };
struct __attribute__((packed)) VoiceReqPayload { uint16_t msgId; };

// For a voice note the bitmap of VOICE_BITMAP_BYTES follows. Bit n set means fragment n arrived.
struct __attribute__((packed)) AckPayload { uint16_t ackedMsgId; };

struct __attribute__((packed)) ReceiptPayload { uint16_t msgId; uint8_t status; };
struct __attribute__((packed)) SosPayload { int32_t lat; int32_t lon; };

inline uint8_t makeVerType(uint8_t type) { return (PROTOCOL_VERSION << PKT_VERSION_SHIFT) | type; }
inline uint8_t packetVersion(uint8_t verType) { return verType >> PKT_VERSION_SHIFT; }
inline uint8_t packetType(uint8_t verType) { return verType & PKT_TYPE_MASK; }

inline bool packetHasTag(uint8_t type) {
  return type != PKT_BEACON && type != PKT_SERVER_HELLO && type != PKT_JOIN;
}

# Values in the first two blocks must equal the ones in shared/config.h.

# Radio link
SERIAL_PORT = "/dev/ttyUSB0"  # a native USB board shows up as /dev/ttyACM0 instead
LINK_BAUD = 460800
LINK_MAX_PAYLOAD = 288
LINK_FRAME_TIMEOUT_MS = 50
RADIO_READY_TIMEOUT_MS = 3000
RADIO_RESET_PULSE_MS = 20
RADIO_POWER_PRESET = 3
TX_RESULT_TIMEOUT_MS = 6000

# Timing and voice
BEACON_INTERVAL_S = 60
BEACON_JITTER_PCT = 20
ACK_TIMEOUT_MS = 3000
VOICE_ACK_TIMEOUT_MS = 6000
SEND_RETRY_MAX = 3
RETRY_BACKOFF_MS = 1500
REASSEMBLY_TIMEOUT_MS = 30000
VOICE_MAX_S = 10
VOICE_FRAG_BYTES = 48
VOICE_USE_1200 = False
VOICE_FRAME_MS = 40
VOICE_FRAME_BITS = 48 if VOICE_USE_1200 else 28
VOICE_MAX_BYTES = (VOICE_MAX_S * 1000 // VOICE_FRAME_MS * VOICE_FRAME_BITS + 7) // 8

# This server. Set the position to where the antenna is. The name is at most 12 ASCII characters.
SERVER_NAME = "relay"
SERVER_LAT = 28.6139
SERVER_LON = 77.2090
IDENTITY_PATH = "/var/lib/offgrid/identity.key"

# Storage and delivery
DB_PATH = "/var/lib/offgrid/server.db"
DB_MAX_BYTES = 256 * 1024 * 1024
DB_COMMIT_INTERVAL_S = 5
MESSAGE_TTL_DAYS = 7
VOICE_NEWEST_WINS = False
MISSING_AFTER_DAYS = 3
DEVICE_LOST_BEACONS = 3

# Validation
RATE_LIMIT_PACKETS = 60
RATE_LIMIT_WINDOW_S = 60
BLOCK_AFTER_DROPS = 10
BLOCK_SECONDS = 600

# Internet bridge
BRIDGE_HOST = "0.0.0.0"
BRIDGE_PORT = 8765
TLS_CERT_PATH = "/etc/offgrid/cert.pem"
TLS_KEY_PATH = "/etc/offgrid/key.pem"

# Log
LOG_LEVEL = "INFO"
LOG_PATH = "/var/log/offgrid/server.log"
LOG_MAX_BYTES = 1024 * 1024
LOG_BACKUP_COUNT = 3

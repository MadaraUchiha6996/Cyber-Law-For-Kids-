# Hardware Map and Board Review (from pcb.net, 2026-10-10)

## 1. Real pin map (read from your netlist)

### Main ESP32-S3 (U3)

| Function | Where | GPIO / note |
|---|---|---|
| OLED I2C | J4: 1 GND, 2 3V3, 3 SCL, 4 SDA | SCL = GPIO8, SDA = GPIO7, OLED address 0x3C |
| IMU ICM-20948 | U6, runs at 1.8 V through level shifter U9 | same I2C bus, address 0x69 (AD0 tied high), INT1 = GPIO9 |
| Button B1 (up) | SW5 | GPIO21 |
| Button B2 (middle) | SW3 | GPIO14 |
| Button B3 (back) | SW4 | GPIO10 |
| BOOT / RESET | SW1 / SW2 | GPIO0 / CHIP_PU (hardware only) |
| Speaker amp MAX98357A | U5, output on J10 | DIN = GPIO4, BCLK = GPIO5, LRCLK = GPIO6 |
| Microphone | J8: 1 3V3, 2 GND, 3 GND, 4 GPIO12, 5 GPIO11, 6 GPIO13 | assumed I2S: BCLK = GPIO12, WS = GPIO11, DIN = GPIO13 (L/R tied to GND) |
| GPS | J5: 1 3V3, 2 GND, 3 GPIO17, 4 GPIO18 | **on the main ESP**, UART1 |
| Link to radio ESP | via J7 net | S3 TX = GPIO33, S3 RX = GPIO34 |
| Radio enable / reset | LORA_EN net | GPIO2 (10k pull-up, low = radio off) |
| USB | J1 | GPIO19 / GPIO20, native USB |
| Console UART | J3: 1 3V3, 2 TX, 3 RX, 4 GND | U0TXD / U0RXD |

Buttons have no external pull-ups: use INPUT_PULLUP and debounce in software.
Free GPIOs for fixes below: GPIO1 (ADC), GPIO35, 36, 37, 38 (also 39 to 42). Avoid GPIO3, 45, 46 (strapping).

### Radio ESP (U7, HT-CT62 = ESP32-C3 + SX1262)

| Function | Where |
|---|---|
| Link to main | UART0: RX = GPIO20, TX = GPIO21 (module pins 19, 20) |
| Enable | EN pin, driven by S3 GPIO2 |
| Flash header J7 | 1 = radio TX (also S3 GPIO34), 2 = radio RX (also S3 GPIO33), 3 = EN, 4 = GPIO9 (boot strap), 5 = GND |
| LoRa antenna | J11 (U.FL) |
| 2.4 GHz antenna | J9 (the C3's own WiFi/BLE, not needed) |
| SX1262 to C3 wiring | inside the module, not in your netlist. The prompt tells the AI to take it from Heltec's HT-CT62 datasheet |

Per the module schematic, the SX1262 has crystal pins (no TCXO) and DIO2 drives an RF switch. Confirm both in the datasheet before trusting the radio code.

## 2. How everything connects

1. **Main to LoRa chip:** S3 GPIO33/34 to the C3's UART0 at 460800 baud, framed packets with CRC. GPIO2 enables or resets the radio. The C3 prints boot text on UART0, so the main ESP ignores bytes until it sees a valid frame, and the radio firmware must not log on that UART.
2. **LoRa chip to the air:** SX1262 (inside U7) to the U.FL socket J11 to your high-gain antenna.
3. **Device to server:** only over LoRa. The device beacons, the server hears it, sends a JOIN reply, and the device is "connected". "Connect to server" on screen just picks which server to join. Same radio, same frequency, same spreading factor on every unit.
4. **The server is the same board** with different firmware. It needs the same radio firmware as the devices and its own main program. It has no SD card, so queues go in the 4 MB flash (about 2 MB for data).
5. **Internet mode:** S3 WiFi (antenna J6) to your router to the server's WiFi. Same encrypted packets, different transport.

## 3. High-gain antenna

- Plug it into **J11**. Use a 50 ohm antenna for 865 to 867 MHz (868 MHz antennas work). Keep the U.FL-to-SMA cable short.
- **Never transmit without the antenna connected.** It can damage the SX1262 output stage.
- Mount it vertical, away from metal and the battery. Put the server's antenna as high as you can.
- India rules (865 to 867 MHz): up to 1 W transmit power, 4 W effective radiated power, 200 kHz maximum bandwidth. So the code uses **125 kHz bandwidth only** and caps power. The SX1262 maxes at +22 dBm, so an antenna up to about 12 dBi stays inside the limit. Check the current WPC rules before deploying.
- HT-CT62 comes in band variants (Heltec lists 863 to 870 MHz and 902 to 928 MHz). Yours must be the 863 to 870 MHz one.
- J6 (S3 WiFi): the 1 pF shunt caps and 0 ohm resistor are placeholders. Keep that trace 50 ohm and check range when you test internet mode.

## 4. Problems and fixes

**Fix before ordering the board**
1. **No battery voltage sensing.** Nothing connects VBAT to an ADC pin, so battery % cannot work. Add 220k + 220k divider from VBAT to GND, middle point to **GPIO1** with 0.1 uF to GND.
2. **Speaker amp can never switch off.** R11 ties SD_MODE to 3V3, so the MAX98357A draws roughly 2 to 3 mA all the time. Move R11's free end from 3V3 to **GPIO35** instead: high = on (mono mix mode), low = shutdown.
3. **GPS has no power control.** J5 is wired straight to 3V3, so "GPS OFF" cannot save power. Add a P-MOSFET high-side switch from a free GPIO (GPIO37), or accept software standby only.
4. **BQ24074 PGOOD (U2 pin 7) is unconnected.** Route it to **GPIO36** with a 100k pull-up to 3V3 so the firmware knows USB is plugged in (needed to read battery % correctly while charging).
5. **Radio ESP cannot be reflashed from the S3.** GPIO9 is not routed to the S3. Route J7 pin 4 to **GPIO38**. Otherwise flash the radio through J7 with a USB-UART adapter, jumpering GPIO9 to GND and pulsing EN, with the S3 pins GPIO33/34 left floating.

**Check on the real parts**
6. **Connector pin order.** J4, J5 and J8 are in a fixed order, but cheap OLED, GPS and mic modules come in different orders. Reversed power kills them. Match every cable to your module's silkscreen before powering.
7. **Battery connector J2:** pin 1 is +, pin 2 is GND. JST-PH packs are often wired the other way.
8. **Charge current.** R5 (1.75k) sets about 0.5 A and the input limit is 500 mA. Your battery's rated charge current must be at least 0.5 A, otherwise raise R5.
9. **No power switch.** The firmware uses deep sleep as "off" (all three buttons wake it). Add a slide switch if you want true off.
10. **No buzzer needed.** Alert beeps play through the speaker.
11. **Flash is 4 MB.** One app slot plus storage. No room for OTA with two slots.
12. **I2C goes through a TXS0104E level shifter.** Run I2C at 100 kHz.

**Looks correct**
USB-C and ESD, charger power path, 3.3 V and 1.8 V rails, S3 supply pins, 40 MHz crystal, reset and boot circuit, IMU wiring, speaker wiring, UART link, radio enable line, button wiring.

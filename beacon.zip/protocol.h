#pragma once

#include <stdint.h>
#include "config.h"

// Multi-byte fields are little endian on the wire.
// Nonce layout, key derivation and the message flows are in protocol.md.
#define WIRE_STRUCT struct __attribute__((packed))

// UART link: start | len(2) | type | payload | crc16(2). len counts the payload only.
// The CRC covers len, type and payload.
#define LINK_START_BYTE         0xA5
#define LINK_OVERHEAD_BYTES     6
#define LINK_CRC_INIT           0xFFFF
#define LINK_CRC_POLY           0x1021

// Types with the top bit set travel from the radio to the host.
enum LinkMsg : uint8_t {
  LINK_MSG_SEND_PACKET = 0x01,
  LINK_MSG_SET_POWER   = 0x02,
  LINK_MSG_SET_BEACON  = 0x03,
  LINK_MSG_READY       = 0x81,
  LINK_MSG_RX_PACKET   = 0x82,
  LINK_MSG_TX_RESULT   = 0x83
};

enum PowerPreset : uint8_t {
  POWER_SHORT,
  POWER_MEDIUM,
  POWER_LONG,
  POWER_MAX
};

enum TxResult : uint8_t {
  TX_OK,
  TX_CHANNEL_BUSY,
  TX_RADIO_ERROR
};

enum ReadyStatus : uint8_t {
  READY_OK,
  READY_RADIO_FAILED
};

// SEND_PACKET payload: LinkSendInfo, then the finished LoRa packet.
// The handle comes back in TX_RESULT so the host can match the answer.
WIRE_STRUCT LinkSendInfo {
  uint8_t handle;
};

WIRE_STRUCT LinkTxResult {
  uint8_t handle;
  uint8_t result;
};

// RX_PACKET payload: LinkRxInfo, then the LoRa packet as received.
WIRE_STRUCT LinkRxInfo {
  int8_t rssi;
  int8_t snr;
};

// SET_BEACON payload: LinkBeaconInfo, then the finished beacon packet.
WIRE_STRUCT LinkBeaconInfo {
  uint16_t intervalS;
};

// LoRa packet: header | payload | tag. BEACON, SERVER_HELLO and JOIN have no tag
// because no hop key exists yet when they are sent.
#define PROTOCOL_VERSION        1
#define PKT_VERSION_SHIFT       4
#define PKT_TYPE_MASK           0x0F

#define ID_NONE                 0x0000
#define ID_BROADCAST            0xFFFF

#define TAG_BYTES               16
#define KEY_BYTES               32
#define PUBKEY_BYTES            32
#define E2E_NONCE_BYTES         12
#define JOIN_NONCE_BYTES        8
#define NAME_BYTES              12

#define HOP_KEY_INFO            "offgrid-hop-v1"
#define E2E_KEY_INFO            "offgrid-e2e-v1"

enum PacketType : uint8_t {
  PKT_BEACON       = 1,
  PKT_SERVER_HELLO = 2,
  PKT_JOIN         = 3,
  PKT_JOIN_ACK     = 4,
  PKT_DEVLIST_REQ  = 5,
  PKT_DEVLIST      = 6,
  PKT_TEXT         = 7,
  PKT_VOICE_META   = 8,
  PKT_VOICE_FRAG   = 9,
  PKT_VOICE_REQ    = 10,
  PKT_VOICE_SLOT_FREE = 11,
  PKT_ACK          = 12,
  PKT_RECEIPT      = 13,
  PKT_SOS          = 14
};

WIRE_STRUCT PacketHeader {
  uint8_t  verType;
  uint16_t src;
  uint16_t dst;
  uint16_t msgId;
  uint8_t  fragIdx;
  uint8_t  fragTotal;
  uint8_t  len;
};

#define HEADER_BYTES            sizeof(PacketHeader)
#define PKT_MAX_PAYLOAD         (LORA_MAX_PAYLOAD - HEADER_BYTES - TAG_BYTES)

inline uint8_t makeVerType(uint8_t type) { return (PROTOCOL_VERSION << PKT_VERSION_SHIFT) | type; }
inline uint8_t packetVersion(uint8_t verType) { return verType >> PKT_VERSION_SHIFT; }
inline uint8_t packetType(uint8_t verType) { return verType & PKT_TYPE_MASK; }

inline bool packetHasTag(uint8_t type) {
  return type != PKT_BEACON && type != PKT_SERVER_HELLO && type != PKT_JOIN;
}

// Positions are degrees times 1e7. A set NO_FIX flag means lat and lon are not valid.
#define BEACON_FLAG_SERVER      0x01
#define BEACON_FLAG_NO_FIX      0x02

WIRE_STRUCT BeaconPayload {
  uint8_t flags;
  int32_t lat;
  int32_t lon;
  char    name[NAME_BYTES];
};

WIRE_STRUCT JoinPayload {
  uint8_t pubkey[PUBKEY_BYTES];
  uint8_t nonce[JOIN_NONCE_BYTES];
  char    name[NAME_BYTES];
};

WIRE_STRUCT JoinAckPayload {
  uint8_t pubkey[PUBKEY_BYTES];
  uint8_t nonce[JOIN_NONCE_BYTES];
};

#define DEV_FLAG_ONLINE         0x01
#define DEV_FLAG_MISSING        0x02
#define DEV_FLAG_UNRESPONSIVE   0x04
#define DEV_FLAG_NO_FIX         0x08

// The public key is included so a sender can encrypt to the device without another request.
WIRE_STRUCT DevEntry {
  uint16_t id;
  uint8_t  flags;
  int32_t  lat;
  int32_t  lon;
  uint32_t ageS;
  char     name[NAME_BYTES];
  uint8_t  pubkey[PUBKEY_BYTES];
};

#define DEVLIST_PER_PACKET      (PKT_MAX_PAYLOAD / sizeof(DevEntry))

// TEXT payload: e2e nonce | ciphertext | e2e tag. One packet, never fragmented.
#define TEXT_MAX_BYTES          100

// The voice blob is e2e nonce | ciphertext | e2e tag, cut into VOICE_FRAG_BYTES pieces.
#define E2E_OVERHEAD_BYTES      (E2E_NONCE_BYTES + TAG_BYTES)
#define VOICE_BLOB_MAX          (VOICE_MAX_BYTES + E2E_OVERHEAD_BYTES)
#define VOICE_MAX_FRAGS         ((VOICE_BLOB_MAX + VOICE_FRAG_BYTES - 1) / VOICE_FRAG_BYTES)
#define VOICE_BITMAP_BYTES      ((VOICE_MAX_FRAGS + 7) / 8)

enum VoiceCodec : uint8_t {
  CODEC_700C,
  CODEC_1200
};

#define VOICE_CODEC_ID          (VOICE_USE_1200 ? CODEC_1200 : CODEC_700C)

WIRE_STRUCT VoiceMetaPayload {
  uint16_t blobBytes;
  uint8_t  codec;
};

// Asks the server to send the voice note whose message id is voiceMsgId.
WIRE_STRUCT VoiceReqPayload {
  uint16_t voiceMsgId;
};

// The bitmap is only present when acknowledging a voice note. Bit n set means fragment n arrived.
WIRE_STRUCT AckPayload {
  uint16_t ackedMsgId;
  uint8_t  bitmap[VOICE_BITMAP_BYTES];
};

enum ReceiptStatus : uint8_t {
  RECEIPT_DELIVERED         = 1,
  RECEIPT_READ              = 2,
  RECEIPT_RECIPIENT_MISSING = 3,
  RECEIPT_FAILED_NO_DEST    = 4,
  RECEIPT_FAILED_EXPIRED    = 5,
  RECEIPT_FAILED_REFUSED    = 6
};

WIRE_STRUCT ReceiptPayload {
  uint16_t msgId;
  uint8_t  status;
};

WIRE_STRUCT SosPayload {
  int32_t lat;
  int32_t lon;
};

// A sender starts a new session before its message id counter reaches MSG_ID_LIMIT,
// so a hop nonce is never used twice under one key.
#define MSG_ID_LIMIT            0xFF00
#define REPLAY_WINDOW           64

#pragma once

#include <stdint.h>
#include "config.h"

// All multi-byte fields are little endian. Must match protocol.py.

#define LINK_START_BYTE         0xA5
#define LINK_OVERHEAD_BYTES     6
#define LINK_CRC_INIT           0xFFFF
#define LINK_CRC_POLY           0x1021

#define LINK_MSG_SEND_PACKET    0x01
#define LINK_MSG_SET_POWER      0x02
#define LINK_MSG_SET_BEACON     0x03
#define LINK_MSG_READY          0x81
#define LINK_MSG_RX_PACKET      0x82
#define LINK_MSG_TX_RESULT      0x83

#define READY_OK                0
#define READY_RADIO_FAILED      1

#define TX_OK                   0
#define TX_CHANNEL_BUSY         1
#define TX_RADIO_ERROR          2

#define POWER_MAX               3

// Size of the LoRa packet header: type, src, dst, msg_id, frag_idx, frag_total, length.
#define HEADER_BYTES            10

struct __attribute__((packed)) LinkSendInfo { uint8_t handle; };
struct __attribute__((packed)) LinkTxResult { uint8_t handle; uint8_t result; };
struct __attribute__((packed)) LinkRxInfo { int8_t rssi; int8_t snr; };
struct __attribute__((packed)) LinkBeaconInfo { uint16_t intervalS; };

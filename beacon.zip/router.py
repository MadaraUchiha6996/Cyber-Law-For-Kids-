import asyncio
import logging
import os
import time
from dataclasses import dataclass, field

import config
import db
import registry
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from protocol import (ACK, BEACON, DEV_ENTRY, DEVLIST_PER_PACKET, ID_BROADCAST, JOIN, JOIN_ACK, MSG_ID_LIMIT,
                      RECEIPT, VOICE_FRAG_BYTES, VOICE_META, BeaconFlag, PacketType,
                      ReceiptStatus, derive_hop_key, device_id, build_packet, make_bitmap,
                      missing_fragments, to_e7, unpack_name)
from radio_link import Priority
from validator import Drop, validate

log = logging.getLogger(__name__)

HELLO_GAP_S = 30
EXPIRY_SWEEP_S = 60


@dataclass
class Incoming:
    dst: int
    total: int
    codec: int
    started: float
    last_rx: float
    acked_at: float = 0.0
    frags: dict[int, bytes] = field(default_factory=dict)


@dataclass
class Outgoing:
    row: int
    src: int
    msg_id: int
    codec: int
    frags: list[bytes]
    sent_at: float = 0.0
    tries: int = 0


def load_identity() -> X25519PrivateKey:
    try:
        with open(config.IDENTITY_PATH, "rb") as f:
            return X25519PrivateKey.from_private_bytes(f.read())
    except FileNotFoundError:
        key = X25519PrivateKey.generate()
        fd = os.open(config.IDENTITY_PATH, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(key.private_bytes_raw())
        return key


class Router:
    def __init__(self):
        self.radio = None
        self._private = load_identity()
        self._public = self._private.public_key().public_bytes_raw()
        self.id = device_id(self._public)
        self._next_id = int.from_bytes(os.urandom(2), "little") % MSG_ID_LIMIT
        self._incoming: dict[tuple[int, int], Incoming] = {}
        self._finished: dict[tuple[int, int], int] = {}
        self._outgoing: dict[int, Outgoing] = {}
        self._text_sent: dict[int, float] = {}
        self._flushing: set[int] = set()
        self._hello_at: dict[int, float] = {}
        self._notified: set[tuple[int, int]] = set()
        self._tasks: set[asyncio.Task] = set()
        self._swept_at = 0.0

    def attach(self, radio) -> None:
        self.radio = radio

    # Called by the radio link for every received packet. Handling is async, so it runs as its own task.
    def on_packet(self, data: bytes, rssi: int, snr: int) -> None:
        self._spawn(self._handle(data))

    def _spawn(self, coro) -> None:
        task = asyncio.get_running_loop().create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        task.add_done_callback(self._log_failure)

    @staticmethod
    def _log_failure(task: asyncio.Task) -> None:
        if not task.cancelled() and task.exception():
            log.error("handler failed", exc_info=task.exception())

    async def start(self) -> None:
        await self.radio.wait_ready()
        beacon = BEACON.pack(BeaconFlag.SERVER, to_e7(config.SERVER_LAT), to_e7(config.SERVER_LON),
                             config.SERVER_NAME.encode("ascii"))
        await self.radio.set_beacon(self._build(PacketType.BEACON, ID_BROADCAST, beacon), config.BEACON_INTERVAL_S)
        await self._send(self._build(PacketType.SERVER_HELLO, ID_BROADCAST))

    def _new_id(self) -> int:
        self._next_id = (self._next_id + 1) % MSG_ID_LIMIT
        return self._next_id

    def _build(self, packet_type, dst, payload=b"", msg_id=None, src=None, frag_idx=0, frag_total=1) -> bytes:
        target = registry.get(dst)
        return build_packet(packet_type, self.id if src is None else src, dst,
                            self._new_id() if msg_id is None else msg_id, payload,
                            target.hop_key if target else None, frag_idx, frag_total)

    async def _send(self, packet: bytes, priority: Priority = Priority.URGENT) -> bool:
        result = await self.radio.send(packet, priority)
        return result == 0

    async def _to_device(self, dst: int, packet_type, payload=b"", **fields) -> bool:
        registry.sent_to(dst)
        return await self._send(self._build(packet_type, dst, payload, **fields))

    async def _receipt(self, dst: int, msg_id: int, status: ReceiptStatus) -> None:
        if registry.get(dst):
            await self._to_device(dst, PacketType.RECEIPT, RECEIPT.pack(msg_id, status))

    async def _handle(self, data: bytes) -> None:
        try:
            packet, sender = validate(data)
        except Drop as drop:
            await self._on_drop(drop)
            return
        if packet.type == PacketType.BEACON:
            await self._on_beacon(packet)
            return
        if packet.type == PacketType.JOIN:
            await self._on_join(packet)
            return
        if not sender:
            return
        registry.heard(sender.id)
        registry.responded(sender.id)
        handler = {
            PacketType.DEVLIST_REQ: self._on_devlist_req, PacketType.TEXT: self._on_text,
            PacketType.VOICE_META: self._on_voice_meta, PacketType.VOICE_FRAG: self._on_voice_frag,
            PacketType.VOICE_REQ: self._on_slot_free, PacketType.VOICE_SLOT_FREE: self._on_slot_free,
            PacketType.ACK: self._on_ack, PacketType.RECEIPT: self._on_receipt, PacketType.SOS: self._on_sos,
        }.get(packet.type)
        if handler:
            await handler(packet)
        self._flush_later(sender.id)

    async def _on_drop(self, drop: Drop) -> None:
        packet = drop.packet
        log.debug("dropped: %s", drop.reason)
        if not packet or not registry.get(packet.src):
            return
        if drop.reason == "no destination":
            await self._receipt(packet.src, packet.msg_id, ReceiptStatus.FAILED_NO_DEST)
        elif drop.reason == "duplicate":
            # The sender repeats a packet when our ACK was lost, so it gets the ACK again.
            if packet.type == PacketType.TEXT:
                await self._ack(packet.src, packet.msg_id)
            elif packet.type == PacketType.VOICE_FRAG:
                await self._voice_ack(packet.src, packet.msg_id)

    async def _on_beacon(self, packet) -> None:
        flags, lat, lon, _ = BEACON.unpack(packet.payload)
        if flags & BeaconFlag.SERVER:
            return
        if registry.get(packet.src):
            registry.heard(packet.src, lat, lon, bool(flags & BeaconFlag.NO_FIX))
            self._flush_later(packet.src)
            return
        now = time.time()
        if now - self._hello_at.get(packet.src, 0) >= HELLO_GAP_S:
            self._hello_at[packet.src] = now
            await self._send(self._build(PacketType.SERVER_HELLO, packet.src))

    async def _on_join(self, packet) -> None:
        public, device_nonce, name = JOIN.unpack(packet.payload)
        server_nonce = os.urandom(8)
        try:
            hop_key = derive_hop_key(self._private, public, device_nonce, server_nonce)
            device = registry.add(public, unpack_name(name), hop_key)
        except ValueError as err:
            log.warning("join refused: %s", err)
            return
        if device.id != packet.src:
            log.warning("join refused: id does not match key")
            return
        await self._to_device(device.id, PacketType.JOIN_ACK, JOIN_ACK.pack(self._public, server_nonce))
        log.info("joined: %s (%04x)", device.name, device.id)

    async def _on_devlist_req(self, packet) -> None:
        now = time.time()
        entries = [DEV_ENTRY.pack(d.id, registry.flags(d), d.lat, d.lon, int(now - d.last_seen),
                                  d.name.encode("ascii"), d.public_key)
                   for d in registry.all_devices() if d.id != packet.src]
        if not entries:
            await self._ack(packet.src, packet.msg_id)
            return
        pages = [entries[i:i + DEVLIST_PER_PACKET] for i in range(0, len(entries), DEVLIST_PER_PACKET)]
        for number, page in enumerate(pages):
            await self._to_device(packet.src, PacketType.DEVLIST, b"".join(page), msg_id=packet.msg_id,
                                  frag_idx=number, frag_total=len(pages))

    async def _ack(self, dst: int, msg_id: int, bitmap: bytes = b"") -> None:
        await self._to_device(dst, PacketType.ACK, ACK.pack(msg_id) + bitmap, msg_id=msg_id)

    async def _on_text(self, packet) -> None:
        db.add_message(packet.src, packet.dst, packet.msg_id, db.KIND_TEXT, packet.payload)
        await self._ack(packet.src, packet.msg_id)
        await self._tell_if_missing(packet.src, packet.dst, packet.msg_id)

    async def _tell_if_missing(self, src: int, dst: int, msg_id: int) -> None:
        target = registry.get(dst)
        if target and registry.is_missing(target) and (src, msg_id) not in self._notified:
            self._notified.add((src, msg_id))
            await self._receipt(src, msg_id, ReceiptStatus.RECIPIENT_MISSING)

    async def _on_voice_meta(self, packet) -> None:
        total, codec = VOICE_META.unpack(packet.payload)
        now = time.time()
        # One upload per sender at a time, a new one replaces the old.
        for key in [k for k in self._incoming if k[0] == packet.src]:
            del self._incoming[key]
        self._incoming[(packet.src, packet.msg_id)] = Incoming(packet.dst, total, codec, now, now)

    async def _on_voice_frag(self, packet) -> None:
        upload = self._incoming.get((packet.src, packet.msg_id))
        if not upload or packet.frag_total != upload.total:
            return
        upload.frags[packet.frag_idx] = packet.payload
        upload.last_rx = time.time()
        if len(upload.frags) == upload.total:
            await self._finish_upload(packet.src, packet.msg_id, upload)
        elif packet.frag_idx == upload.total - 1:
            await self._voice_ack(packet.src, packet.msg_id)

    async def _finish_upload(self, src: int, msg_id: int, upload: Incoming) -> None:
        blob = b"".join(upload.frags[n] for n in range(upload.total))
        del self._incoming[(src, msg_id)]
        self._finished[(src, msg_id)] = upload.total
        if len(self._finished) > 64:
            del self._finished[next(iter(self._finished))]
        db.add_message(src, upload.dst, msg_id, db.KIND_VOICE, blob, upload.codec)
        await self._ack(src, msg_id, make_bitmap(range(upload.total)))
        await self._tell_if_missing(src, upload.dst, msg_id)
        self._flush_later(upload.dst)

    # One ACK that carries a bitmap of every fragment received so far.
    async def _voice_ack(self, src: int, msg_id: int) -> None:
        upload = self._incoming.get((src, msg_id))
        if upload:
            upload.acked_at = time.time()
            await self._ack(src, msg_id, make_bitmap(upload.frags))
        elif (src, msg_id) in self._finished:
            await self._ack(src, msg_id, make_bitmap(range(self._finished[(src, msg_id)])))

    async def _on_slot_free(self, packet) -> None:
        registry.set_voice_busy(packet.src, False)

    async def _on_ack(self, packet) -> None:
        msg_id = ACK.unpack_from(packet.payload)[0]
        bitmap = packet.payload[ACK.size:]
        voice = self._outgoing.get(packet.src)
        if bitmap and voice and voice.msg_id == msg_id and voice.src == packet.dst:
            await self._on_voice_ack(packet.src, voice, bitmap)
            return
        row = db.get_message(packet.dst, packet.src, msg_id)
        if row and row["kind"] == db.KIND_TEXT and row["state"] == db.STATE_QUEUED:
            db.mark_delivered(row["row"])
            self._text_sent.pop(packet.src, None)
            await self._receipt(packet.dst, msg_id, ReceiptStatus.DELIVERED)

    async def _on_voice_ack(self, dst: int, voice: Outgoing, bitmap: bytes) -> None:
        missing = missing_fragments(bitmap, len(voice.frags))
        if missing:
            for number in missing:
                await self._send_fragment(dst, voice, number)
            voice.sent_at = time.time()
            return
        del self._outgoing[dst]
        db.mark_delivered(voice.row)
        registry.set_voice_busy(dst, True)
        await self._receipt(voice.src, voice.msg_id, ReceiptStatus.DELIVERED)

    async def _on_receipt(self, packet) -> None:
        if registry.get(packet.dst):
            msg_id, status = RECEIPT.unpack(packet.payload)
            await self._receipt(packet.dst, msg_id, ReceiptStatus(status))

    async def _on_sos(self, packet) -> None:
        for device in registry.all_devices():
            if device.id != packet.src:
                await self._to_device(device.id, PacketType.SOS, packet.payload,
                                      src=packet.src, msg_id=packet.msg_id)

    def _flush_later(self, dev_id: int) -> None:
        if dev_id not in self._flushing:
            self._flushing.add(dev_id)
            self._spawn(self._flush(dev_id))

    # Sends the next waiting message to a device that was just heard, one at a time.
    async def _flush(self, dev_id: int) -> None:
        try:
            device = registry.get(dev_id)
            if not device or dev_id in self._outgoing:
                return
            now = time.time()
            if now - self._text_sent.get(dev_id, 0) < config.ACK_TIMEOUT_MS / 1000:
                return
            row = db.next_queued(dev_id, not device.voice_busy)
            if not row:
                return
            if row["kind"] == db.KIND_TEXT:
                self._text_sent[dev_id] = now
                await self._to_device(dev_id, PacketType.TEXT, row["blob"], src=row["src"], msg_id=row["msg_id"])
            else:
                await self._send_voice(dev_id, row)
        finally:
            self._flushing.discard(dev_id)

    async def _send_voice(self, dst: int, row) -> None:
        blob = row["blob"]
        voice = Outgoing(row["row"], row["src"], row["msg_id"], row["codec"],
                         [blob[i:i + VOICE_FRAG_BYTES] for i in range(0, len(blob), VOICE_FRAG_BYTES)])
        self._outgoing[dst] = voice
        if not await self._send_meta(dst, voice):
            del self._outgoing[dst]
            return
        for number in range(len(voice.frags)):
            if not await self._send_fragment(dst, voice, number):
                del self._outgoing[dst]
                return
        voice.sent_at = time.time()

    async def _send_meta(self, dst: int, voice: Outgoing) -> bool:
        return await self._to_device(dst, PacketType.VOICE_META, VOICE_META.pack(len(voice.frags), voice.codec),
                                     src=voice.src, msg_id=voice.msg_id)

    async def _send_fragment(self, dst: int, voice: Outgoing, number: int) -> bool:
        packet = self._build(PacketType.VOICE_FRAG, dst, voice.frags[number], msg_id=voice.msg_id,
                             src=voice.src, frag_idx=number, frag_total=len(voice.frags))
        return await self._send(packet, Priority.VOICE)

    # Runs once a second: lost ACKs, stalled uploads, expiry, and the "recipient missing" receipts.
    async def maintain(self) -> None:
        while True:
            await asyncio.sleep(1)
            now = time.time()
            await self._retry_voice(now)
            await self._check_uploads(now)
            if now - self._swept_at >= EXPIRY_SWEEP_S:
                self._swept_at = now
                await self._sweep(now)

    async def _retry_voice(self, now: float) -> None:
        for dst, voice in list(self._outgoing.items()):
            if not voice.sent_at or now - voice.sent_at < config.VOICE_ACK_TIMEOUT_MS / 1000:
                continue
            voice.tries += 1
            if voice.tries > config.SEND_RETRY_MAX:
                del self._outgoing[dst]
                continue
            voice.sent_at = now
            await self._send_meta(dst, voice)
            await self._send_fragment(dst, voice, len(voice.frags) - 1)

    async def _check_uploads(self, now: float) -> None:
        for (src, msg_id), upload in list(self._incoming.items()):
            if now - upload.last_rx > config.REASSEMBLY_TIMEOUT_MS / 1000:
                del self._incoming[(src, msg_id)]
            elif now - upload.last_rx > config.ACK_TIMEOUT_MS / 1000 and upload.acked_at < upload.last_rx:
                await self._voice_ack(src, msg_id)

    async def _sweep(self, now: float) -> None:
        if len(self._notified) > 1000:
            self._notified.clear()
        for row in db.drop_expired():
            await self._receipt(row["src"], row["msg_id"], ReceiptStatus.FAILED_EXPIRED)
        for device in registry.all_devices():
            if registry.is_missing(device):
                for row in db.queued_for(device.id):
                    await self._tell_if_missing(row["src"], device.id, row["msg_id"])

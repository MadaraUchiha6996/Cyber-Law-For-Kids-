# Protocol

Shared by the device firmware (protocol.h) and the Raspberry Pi server (protocol.py).
All multi-byte fields are little endian. If this file and the code disagree, fix the code.

## 1. UART link (main S3 <-> radio ESP, and Pi <-> radio ESP)

460800 baud, 8N1.

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | start byte 0xA5 |
| 1 | 2 | payload length |
| 3 | 1 | message type |
| 4 | n | payload |
| 4+n | 2 | CRC-16/CCITT, poly 0x1021, init 0xFFFF, no reflection, no final xor |

The CRC covers length, type and payload. A receiver that sees a bad length or CRC drops one byte and looks for the next 0xA5. A partial frame is dropped after 50 ms of silence. Largest payload: 288 bytes.

| Type | Dir | Payload |
|---|---|---|
| 0x01 SEND_PACKET | host to radio | handle (u8), then a full LoRa packet |
| 0x02 SET_POWER | host to radio | preset (u8, 0 to 3: +10, +14, +17, +22 dBm) |
| 0x03 SET_BEACON | host to radio | interval in seconds (u16, 0 stops), then the full beacon packet |
| 0x81 READY | radio to host | status (u8: 0 ok, 1 radio failed) |
| 0x82 RX_PACKET | radio to host | rssi (i8), snr (i8), then the LoRa packet |
| 0x83 TX_RESULT | radio to host | handle (u8), result (u8: 0 ok, 1 channel busy, 2 radio error) |

Beacons sent by the radio on its own timer have no TX_RESULT. Only one send is in flight at a time.

## 2. LoRa packet

865.5 MHz, 125 kHz, SF9, coding rate 4/5, sync word 0x5A, CRC on. Largest packet: 255 bytes.

Header, 10 bytes:

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | version (high 4 bits, now 1) and type (low 4 bits) |
| 1 | 2 | src device id |
| 3 | 2 | dst device id (0xFFFF broadcast, 0x0000 none) |
| 5 | 2 | msg_id (below 0xFF00) |
| 7 | 1 | frag_idx |
| 8 | 1 | frag_total |
| 9 | 1 | payload length |

After the payload comes a 16-byte hop tag on every type except BEACON, SERVER_HELLO and JOIN.

Device id = first 2 bytes of SHA-256 of the 32-byte X25519 public key.

## 3. Types and payloads

| # | Type | Payload |
|---|---|---|
| 1 | BEACON | flags (u8: 1 server, 2 no fix), lat (i32), lon (i32), name (12 bytes ASCII, zero padded). Lat and lon are degrees x 10,000,000. |
| 2 | SERVER_HELLO | empty |
| 3 | JOIN | public key (32), device nonce (8), name (12) |
| 4 | JOIN_ACK | server public key (32), server nonce (8) |
| 5 | DEVLIST_REQ | empty |
| 6 | DEVLIST | 1 or more entries of 59 bytes each: id (u16), flags (u8: 1 online, 2 missing, 4 unresponsive, 8 no fix), lat (i32), lon (i32), seconds since last seen (u32), name (12), public key (32) |
| 7 | TEXT | end-to-end blob, 29 to 128 bytes (28 bytes of nonce and tag plus 1 to 100 bytes of text) |
| 8 | VOICE_META | total fragments (u16), codec (u8: 0 Codec2 700C, 1 Codec2 1200) |
| 9 | VOICE_FRAG | 1 to 48 bytes of the end-to-end voice blob, frag_idx and frag_total in the header |
| 10 | VOICE_REQ | msg_id of the voice note (u16) |
| 11 | VOICE_SLOT_FREE | empty |
| 12 | ACK | msg_id acked (u16), then for voice an optional bitmap, 1 bit per fragment, bit n = fragment n received |
| 13 | RECEIPT | msg_id (u16), status (u8: 1 delivered, 2 read, 3 recipient missing, 4 no destination, 5 expired, 6 refused) |
| 14 | SOS | lat (i32), lon (i32) |

Voice note size: 10 s at 700C is 875 bytes, plus 28 for the end-to-end wrapper, split into 48-byte fragments.

## 4. Keys and tags

Hop key (device and server only):
1. Each side makes an X25519 key pair. The device keeps its pair for life.
2. The device sends JOIN. The server answers JOIN_ACK.
3. Both compute the X25519 shared secret.
4. Hop key = HKDF-SHA256 over the shared secret, salt = device nonce followed by server nonce, info = "offgrid-hop-v1", 32 bytes.

Hop tag: ChaCha20-Poly1305 with the hop key, an empty plaintext, the header plus payload as associated data, and the 16-byte output as the tag. Nonce, 12 bytes: src (u16), msg_id (u16), frag_idx (u8), type (u8), 6 zero bytes. A (src, msg_id, frag_idx, type) never repeats under one key.

End-to-end encryption (device to device, the server cannot read it):
1. Key = HKDF-SHA256 over the X25519 shared secret of the two devices, no salt, info "offgrid-e2e-v1", 32 bytes.
2. Blob = 12 random nonce bytes, then ChaCha20-Poly1305 ciphertext, then a 16-byte tag. Associated data: src, dst and msg_id as in the header.
3. TEXT carries the whole blob. A voice note is encrypted first, then cut into VOICE_FRAGs.

Replay: the server keeps the last 64 msg_ids per device and drops repeats and older ones.

## 5. Checks the server makes, in order

1. Length at least 10, version 1, known type, length field equal to what arrived.
2. Sender not blocked.
3. Payload length allowed for that type.
4. Not over the rate limit.
5. Sender registered and hop tag valid (BEACON, SERVER_HELLO and JOIN have no tag).
6. Not a repeat of a packet already handled (a retry is acknowledged again but not processed twice).
7. Fragments: frag_idx below frag_total, total within the voice limit; one-packet types use 0 and 1.
8. Contents: beacon position in range, names plain ASCII, voice size and codec valid.
9. For TEXT and voice, the destination device exists.

A bad packet from a registered sender counts as a strike. After ten strikes in a row the sender is blocked for ten minutes. Duplicates, unknown senders and unknown destinations are dropped without a strike.

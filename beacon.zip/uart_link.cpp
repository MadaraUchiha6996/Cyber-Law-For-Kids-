#include <Arduino.h>
#include "protocol.h"
#include "uart_link.h"

static HardwareSerial radioSerial(LINK_UART_PORT);

static uint8_t rx[LINK_OVERHEAD_BYTES + LINK_MAX_PAYLOAD];
static size_t rxLen;
static uint32_t lastByteAt;
static uint32_t resetAt;
static bool resetting;

static uint16_t crcUpdate(uint16_t crc, const uint8_t* data, size_t len) {
  while (len--) {
    crc ^= (uint16_t)*data++ << 8;
    for (uint8_t bit = 0; bit < 8; bit++) {
      crc = (crc & 0x8000) ? (crc << 1) ^ LINK_CRC_POLY : crc << 1;
    }
  }
  return crc;
}

static void discard(size_t count) {
  memmove(rx, rx + count, rxLen - count);
  rxLen -= count;
}

// The radio prints boot text on this wire, so anything that is not a good frame is skipped one byte at a time.
static bool frameReady(uint8_t& type, uint8_t* payload, uint16_t& len) {
  for (;;) {
    size_t skip = 0;
    while (skip < rxLen && rx[skip] != LINK_START_BYTE) skip++;
    discard(skip);
    if (rxLen < 3) return false;

    uint16_t payloadLen = rx[1] | (rx[2] << 8);
    if (payloadLen > LINK_MAX_PAYLOAD) {
      discard(1);
      continue;
    }
    size_t total = LINK_OVERHEAD_BYTES + payloadLen;
    if (rxLen < total) return false;

    uint16_t crc = crcUpdate(LINK_CRC_INIT, rx + 1, total - 3);
    if (crc != (rx[total - 2] | (rx[total - 1] << 8))) {
      discard(1);
      continue;
    }
    type = rx[3];
    len = payloadLen;
    memcpy(payload, rx + 4, payloadLen);
    discard(total);
    return true;
  }
}

void linkBegin() {
  pinMode(RADIO_EN_PIN, OUTPUT);
  digitalWrite(RADIO_EN_PIN, HIGH);
  radioSerial.setRxBufferSize(LINK_RX_BUFFER_BYTES);
  radioSerial.begin(LINK_BAUD, SERIAL_8N1, LINK_RX_PIN, LINK_TX_PIN);
}

void linkResetRadio() {
  digitalWrite(RADIO_EN_PIN, LOW);
  resetAt = millis();
  resetting = true;
}

void linkSend(uint8_t type, const void* payload, size_t len, const void* extra, size_t extraLen) {
  size_t total = len + extraLen;
  uint8_t head[4] = { LINK_START_BYTE, (uint8_t)total, (uint8_t)(total >> 8), type };
  uint16_t crc = crcUpdate(LINK_CRC_INIT, head + 1, sizeof(head) - 1);
  crc = crcUpdate(crc, (const uint8_t*)payload, len);
  crc = crcUpdate(crc, (const uint8_t*)extra, extraLen);
  uint8_t tail[2] = { (uint8_t)crc, (uint8_t)(crc >> 8) };

  radioSerial.write(head, sizeof(head));
  radioSerial.write((const uint8_t*)payload, len);
  radioSerial.write((const uint8_t*)extra, extraLen);
  radioSerial.write(tail, sizeof(tail));
}

bool linkPoll(uint8_t& type, uint8_t* payload, uint16_t& len) {
  if (resetting && millis() - resetAt >= RADIO_RESET_PULSE_MS) {
    digitalWrite(RADIO_EN_PIN, HIGH);
    resetting = false;
  }
  while (radioSerial.available()) {
    rx[rxLen++] = radioSerial.read();
    lastByteAt = millis();
    if (frameReady(type, payload, len)) return true;
  }
  if (rxLen && millis() - lastByteAt > LINK_FRAME_TIMEOUT_MS) rxLen = 0;
  return false;
}

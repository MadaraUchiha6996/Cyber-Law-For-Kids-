import sqlite3
import time

import config

KIND_TEXT = 0
KIND_VOICE = 1

STATE_QUEUED = 0
STATE_DELIVERED = 1

SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    public_key BLOB NOT NULL,
    hop_key BLOB NOT NULL,
    lat INTEGER NOT NULL DEFAULT 0,
    lon INTEGER NOT NULL DEFAULT 0,
    first_seen REAL NOT NULL,
    last_seen REAL NOT NULL,
    last_response REAL NOT NULL,
    voice_busy INTEGER NOT NULL DEFAULT 0,
    blocked_until REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
    row INTEGER PRIMARY KEY AUTOINCREMENT,
    src INTEGER NOT NULL,
    dst INTEGER NOT NULL,
    msg_id INTEGER NOT NULL,
    kind INTEGER NOT NULL,
    codec INTEGER NOT NULL DEFAULT 0,
    blob BLOB NOT NULL,
    state INTEGER NOT NULL DEFAULT 0,
    created REAL NOT NULL,
    expires REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS messages_dst ON messages (dst, state, row);
"""

_conn: sqlite3.Connection | None = None


def open_db() -> None:
    global _conn
    _conn = sqlite3.connect(config.DB_PATH)
    _conn.row_factory = sqlite3.Row
    _conn.execute("PRAGMA journal_mode=WAL")
    _conn.executescript(SCHEMA)
    _conn.commit()


def commit() -> None:
    _conn.commit()


def close_db() -> None:
    _conn.commit()
    _conn.close()


def save_device(device_id: int, name: str, public_key: bytes, hop_key: bytes) -> None:
    now = time.time()
    # A device that joins again keeps its history and gets the new keys.
    _conn.execute(
        "INSERT INTO devices (id, name, public_key, hop_key, first_seen, last_seen, last_response)"
        " VALUES (?, ?, ?, ?, ?, ?, ?)"
        " ON CONFLICT(id) DO UPDATE SET name=excluded.name, public_key=excluded.public_key,"
        " hop_key=excluded.hop_key, last_seen=excluded.last_seen",
        (device_id, name, public_key, hop_key, now, now, now))


def load_devices() -> list[sqlite3.Row]:
    return _conn.execute("SELECT * FROM devices").fetchall()


def touch_device(device_id: int, lat: int | None = None, lon: int | None = None) -> None:
    if lat is None:
        _conn.execute("UPDATE devices SET last_seen=? WHERE id=?", (time.time(), device_id))
    else:
        _conn.execute("UPDATE devices SET last_seen=?, lat=?, lon=? WHERE id=?",
                      (time.time(), lat, lon, device_id))


# Called when the device answers something: an ACK, a RECEIPT, or any other packet that is not a beacon.
def mark_response(device_id: int) -> None:
    _conn.execute("UPDATE devices SET last_response=? WHERE id=?", (time.time(), device_id))


def set_voice_busy(device_id: int, busy: bool) -> None:
    _conn.execute("UPDATE devices SET voice_busy=? WHERE id=?", (int(busy), device_id))


def set_blocked(device_id: int, until: float) -> None:
    _conn.execute("UPDATE devices SET blocked_until=? WHERE id=?", (until, device_id))


def add_message(src: int, dst: int, msg_id: int, kind: int, blob: bytes, codec: int = 0) -> None:
    now = time.time()
    if kind == KIND_VOICE and config.VOICE_NEWEST_WINS:
        _conn.execute("DELETE FROM messages WHERE dst=? AND kind=? AND state=?",
                      (dst, KIND_VOICE, STATE_QUEUED))
    _conn.execute(
        "INSERT INTO messages (src, dst, msg_id, kind, codec, blob, created, expires)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (src, dst, msg_id, kind, codec, blob, now, now + config.MESSAGE_TTL_DAYS * 86400))
    trim_to_size()


# Text is always first so it never waits behind a voice note.
# A voice note is only offered when the device has room for it.
def next_queued(dst: int, voice_free: bool) -> sqlite3.Row | None:
    row = _conn.execute(
        "SELECT * FROM messages WHERE dst=? AND state=? AND kind=? ORDER BY row LIMIT 1",
        (dst, STATE_QUEUED, KIND_TEXT)).fetchone()
    if row or not voice_free:
        return row
    return _conn.execute(
        "SELECT * FROM messages WHERE dst=? AND state=? AND kind=? ORDER BY row LIMIT 1",
        (dst, STATE_QUEUED, KIND_VOICE)).fetchone()


# The same msg_id can come from two senders, and one sender can send it to two receivers, so all three identify it.
def get_message(src: int, dst: int, msg_id: int) -> sqlite3.Row | None:
    return _conn.execute("SELECT * FROM messages WHERE src=? AND dst=? AND msg_id=? ORDER BY row DESC LIMIT 1",
                         (src, dst, msg_id)).fetchone()


def queued_for(dst: int) -> list[sqlite3.Row]:
    return _conn.execute("SELECT src, msg_id FROM messages WHERE dst=? AND state=?",
                         (dst, STATE_QUEUED)).fetchall()


def mark_delivered(row: int) -> None:
    _conn.execute("UPDATE messages SET state=?, blob=x'' WHERE row=?", (STATE_DELIVERED, row))


def drop_expired() -> list[sqlite3.Row]:
    expired = _conn.execute("SELECT src, msg_id FROM messages WHERE state=? AND expires<?",
                            (STATE_QUEUED, time.time())).fetchall()
    _conn.execute("DELETE FROM messages WHERE expires<?", (time.time(),))
    return expired


def queued_count(dst: int) -> int:
    return _conn.execute("SELECT COUNT(*) FROM messages WHERE dst=? AND state=?",
                         (dst, STATE_QUEUED)).fetchone()[0]


# The SD card is small, so the oldest queued messages go first when the file is too big.
def trim_to_size() -> None:
    while db_bytes() > config.DB_MAX_BYTES:
        cur = _conn.execute("DELETE FROM messages WHERE row IN"
                            " (SELECT row FROM messages ORDER BY row LIMIT 20)")
        if cur.rowcount == 0:
            return


def db_bytes() -> int:
    # Deleted rows leave free pages in the file, so only pages in use count.
    pages = _conn.execute("PRAGMA page_count").fetchone()[0] - _conn.execute("PRAGMA freelist_count").fetchone()[0]
    return pages * _conn.execute("PRAGMA page_size").fetchone()[0]

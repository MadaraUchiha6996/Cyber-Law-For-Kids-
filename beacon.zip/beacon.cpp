#include <Arduino.h>
#include "protocol.h"
#include "lora.h"
#include "beacon.h"

static uint8_t beacon[LORA_MAX_PAYLOAD];
static size_t beaconLen;
static uint32_t intervalMs;
static uint32_t nextAt;
static bool active;
static bool sending;

static uint32_t jitterMs() {
  return intervalMs * BEACON_JITTER_PCT / 100;
}

void beaconSet(const uint8_t* packet, size_t len, uint16_t intervalS) {
  if (intervalS == 0) {
    active = false;
    return;
  }
  if (len < HEADER_BYTES || len > sizeof(beacon)) return;
  memcpy(beacon, packet, len);
  beaconLen = len;
  intervalMs = intervalS * 1000UL;
  if (!active) {
    active = true;
    nextAt = millis() + random(jitterMs() + 1);
  }
}

void beaconService() {
  if (!active || (int32_t)(millis() - nextAt) < 0) return;
  if (!loraSend(beacon, beaconLen)) return;
  sending = true;
  nextAt = millis() + intervalMs - jitterMs() + random(2 * jitterMs() + 1);
}

bool beaconTxFinished() {
  bool wasBeacon = sending;
  sending = false;
  return wasBeacon;
}

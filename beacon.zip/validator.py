import registry
from protocol import (BEACON, NAME_BYTES, POSITION_SCALE, VOICE_META, VOICE_MAX_FRAGS,
                      PAYLOAD_LENGTHS, Packet, PacketError, PacketType, VoiceCodec, has_tag,
                      parse_packet, verify_tag)

# These go to another device. Everything else is addressed to the server itself.
RELAYED = (PacketType.TEXT, PacketType.VOICE_META, PacketType.VOICE_FRAG)
SINGLE_PACKET = (PacketType.TEXT, PacketType.VOICE_META, PacketType.VOICE_REQ, PacketType.ACK,
                 PacketType.RECEIPT, PacketType.VOICE_SLOT_FREE, PacketType.SOS, PacketType.BEACON,
                 PacketType.JOIN, PacketType.JOIN_ACK, PacketType.DEVLIST_REQ, PacketType.DEVLIST,
                 PacketType.SERVER_HELLO)


class Drop(Exception):
    # counts is True when the sender did something wrong, False for a harmless duplicate or an unknown destination.
    # packet is set when the router may still want to answer it, for example with a RECEIPT.
    def __init__(self, reason: str, counts: bool = True, packet: Packet | None = None):
        super().__init__(reason)
        self.reason = reason
        self.counts = counts
        self.packet = packet


# Returns the packet and, for tagged types, the registered sender. Raises Drop if the packet must not be used.
def validate(data: bytes) -> tuple[Packet, registry.Device | None]:
    try:
        packet = parse_packet(data)
    except PacketError as err:
        raise Drop(str(err), counts=False) from None
    src = packet.src
    try:
        return _check(packet), registry.get(src)
    except Drop as drop:
        # A bad packet can carry any src, so only a sender known to the server collects strikes.
        if drop.counts and registry.get(src):
            registry.strike(src)
        drop.packet = drop.packet or packet
        raise


def _check(packet: Packet) -> Packet:
    if registry.is_blocked(packet.src):
        raise Drop("blocked", counts=False)
    if len(packet.payload) not in PAYLOAD_LENGTHS[packet.type]:
        raise Drop("payload length")
    if not registry.rate_ok(packet.src):
        raise Drop("rate limit")
    sender = registry.get(packet.src)
    if has_tag(packet.type):
        if not sender:
            raise Drop("unknown sender", counts=False)
        if not verify_tag(sender.hop_key, packet):
            raise Drop("bad tag")
        if registry.is_duplicate(packet.src, (packet.type, packet.msg_id, packet.frag_idx)):
            raise Drop("duplicate", counts=False)
    _check_fragments(packet)
    _check_content(packet)
    if packet.type in RELAYED and not registry.get(packet.dst):
        raise Drop("no destination", counts=False)
    registry.good(packet.src)
    return packet


def _check_fragments(packet: Packet) -> None:
    if packet.type == PacketType.VOICE_FRAG:
        if not 1 <= packet.frag_total <= VOICE_MAX_FRAGS or packet.frag_idx >= packet.frag_total:
            raise Drop("fragment numbers")
    elif packet.type in SINGLE_PACKET and (packet.frag_idx != 0 or packet.frag_total != 1):
        raise Drop("fragment numbers")


def _check_content(packet: Packet) -> None:
    if packet.type == PacketType.BEACON:
        _, lat, lon, name = BEACON.unpack(packet.payload)
        if abs(lat) > 90 * POSITION_SCALE or abs(lon) > 180 * POSITION_SCALE:
            raise Drop("position out of range")
        if not _ascii(name):
            raise Drop("name not ascii")
    elif packet.type == PacketType.JOIN:
        if not _ascii(packet.payload[-NAME_BYTES:]):
            raise Drop("name not ascii")
    elif packet.type == PacketType.VOICE_META:
        total, codec = VOICE_META.unpack(packet.payload)
        if not 1 <= total <= VOICE_MAX_FRAGS or codec not in VoiceCodec:
            raise Drop("voice size")


def _ascii(raw: bytes) -> bool:
    text = raw.rstrip(b"\0")
    return all(32 <= b < 127 for b in text)

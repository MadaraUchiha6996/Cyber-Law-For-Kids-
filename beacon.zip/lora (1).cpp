#include <Arduino.h>
#include <SPI.h>
#include <RadioLib.h>
#include "protocol.h"
#include "lora.h"

enum class State : uint8_t { Listening, Backoff, Scanning, Sending };

static SX1262 radio = new Module(SX_NSS, SX_DIO1, SX_RST, SX_BUSY);

static const int8_t presetDbm[] = {
  TX_POWER_SHORT_DBM, TX_POWER_MEDIUM_DBM, TX_POWER_LONG_DBM, TX_POWER_MAX_DBM
};
static const int8_t ceilingDbm = EIRP_LIMIT_DBM - ANTENNA_GAIN_DBI + FEEDLINE_LOSS_DB;

static volatile bool irqFired;
static State state = State::Listening;

static uint8_t rxBuf[LORA_MAX_PAYLOAD];
static size_t rxLen;
static int8_t rxRssi;
static int8_t rxSnr;

static uint8_t txBuf[LORA_MAX_PAYLOAD];
static size_t txLen;
static uint8_t attempts;
static uint32_t waitStart;
static uint32_t waitMs;
static bool txFinished;
static uint8_t txResult;

static void IRAM_ATTR onIrq() {
  irqFired = true;
}

static void finish(uint8_t result) {
  txResult = result;
  txFinished = true;
  state = State::Listening;
  radio.startReceive();
}

static void readPacket() {
  size_t len = radio.getPacketLength();
  if (len >= HEADER_BYTES && radio.readData(rxBuf, len) == RADIOLIB_ERR_NONE) {
    rxLen = len;
    rxRssi = (int8_t)radio.getRSSI();
    rxSnr = (int8_t)radio.getSNR();
  }
  radio.startReceive();
}

static void startScan() {
  state = State::Scanning;
  if (radio.startChannelScan() != RADIOLIB_ERR_NONE) finish(TX_RADIO_ERROR);
}

static void scanDone() {
  if (radio.getChannelScanResult() == RADIOLIB_LORA_DETECTED) {
    if (++attempts >= LBT_MAX_ATTEMPTS) {
      finish(TX_CHANNEL_BUSY);
      return;
    }
    waitMs = random(LBT_BACKOFF_MIN_MS, LBT_BACKOFF_MAX_MS + 1);
    waitStart = millis();
    state = State::Backoff;
    radio.startReceive();
    return;
  }
  state = State::Sending;
  if (radio.startTransmit(txBuf, txLen) != RADIOLIB_ERR_NONE) finish(TX_RADIO_ERROR);
}

static void sendDone() {
  finish(radio.finishTransmit() == RADIOLIB_ERR_NONE ? TX_OK : TX_RADIO_ERROR);
}

bool loraBegin() {
  SPI.begin(SX_SCK, SX_MISO, SX_MOSI, SX_NSS);
  if (radio.begin(LORA_FREQ_MHZ, LORA_BW_KHZ, NETWORK_SF, LORA_CR_DENOM, LORA_SYNC_WORD,
                  TX_POWER_SHORT_DBM, LORA_PREAMBLE_SYMBOLS, SX_TCXO_VOLTS) != RADIOLIB_ERR_NONE ||
      radio.setDio2AsRfSwitch(true) != RADIOLIB_ERR_NONE) {
    return false;
  }
  radio.setDio1Action(onIrq);
  return radio.startReceive() == RADIOLIB_ERR_NONE;
}

void loraSetPower(uint8_t preset) {
  if (preset > POWER_MAX) return;
  radio.setOutputPower(min(presetDbm[preset], ceilingDbm));
}

bool loraSend(const uint8_t* packet, size_t len) {
  if (state != State::Listening || len < HEADER_BYTES || len > sizeof(txBuf)) return false;
  memcpy(txBuf, packet, len);
  txLen = len;
  attempts = 0;
  startScan();
  return true;
}

bool loraTxDone(uint8_t& result) {
  if (!txFinished) return false;
  txFinished = false;
  result = txResult;
  return true;
}

size_t loraReceive(uint8_t* buf, int8_t& rssi, int8_t& snr) {
  size_t len = rxLen;
  if (len) {
    memcpy(buf, rxBuf, len);
    rssi = rxRssi;
    snr = rxSnr;
    rxLen = 0;
  }
  return len;
}

void loraService() {
  if (irqFired) {
    irqFired = false;
    switch (state) {
      case State::Listening:
      case State::Backoff:
        readPacket();
        break;
      case State::Scanning:
        scanDone();
        break;
      case State::Sending:
        sendDone();
        break;
    }
  }
  if (state == State::Backoff && millis() - waitStart >= waitMs) startScan();
}

import asyncio
import itertools
import logging
import time
from collections.abc import Callable
from enum import IntEnum

import serial

from config import (LINK_BAUD, LINK_FRAME_TIMEOUT_MS, LINK_MAX_PAYLOAD, RADIO_POWER_PRESET,
                    RADIO_READY_TIMEOUT_MS, RADIO_REOPEN_S, RADIO_RESET_PULSE_MS, SERIAL_PORT,
                    TX_RESULT_TIMEOUT_MS)
from protocol import (LINK_BEACON_INFO, LINK_OVERHEAD_BYTES, LINK_RX_INFO, LINK_SEND_INFO,
                      LINK_START_BYTE, LINK_TX_RESULT, LinkMsg, ReadyStatus, TxResult, crc16,
                      encode_frame)

log = logging.getLogger(__name__)


class Priority(IntEnum):
    URGENT = 0  # acks, receipts, text, control
    VOICE = 1


class FrameParser:
    def __init__(self):
        self._buf = bytearray()
        self._last = 0.0

    def feed(self, data: bytes) -> list[tuple[int, bytes]]:
        now = time.monotonic()
        if now - self._last >= LINK_FRAME_TIMEOUT_MS / 1000:
            self._buf.clear()  # whatever is left never became a frame
        self._last = now
        self._buf += data
        frames = []
        while self._buf:
            if self._buf[0] != LINK_START_BYTE:
                self._drop_first()
                continue
            if len(self._buf) < 3:
                break
            length = int.from_bytes(self._buf[1:3], "little")
            if length > LINK_MAX_PAYLOAD:
                self._drop_first()
                continue
            total = LINK_OVERHEAD_BYTES + length
            if len(self._buf) < total:
                break
            if crc16(bytes(self._buf[1:total - 2])) != int.from_bytes(self._buf[total - 2:total], "little"):
                self._drop_first()
                continue
            frames.append((self._buf[3], bytes(self._buf[4:total - 2])))
            del self._buf[:total]
        return frames

    def _drop_first(self):
        next_start = self._buf.find(LINK_START_BYTE, 1)
        del self._buf[:next_start if next_start != -1 else len(self._buf)]


class RadioLink:
    def __init__(self, on_packet: Callable[[bytes, int, int], None]):
        self._on_packet = on_packet
        self._serial = None
        self._events = asyncio.Queue()
        self._ready = asyncio.Event()
        self._beacon = None
        self._pending = None
        self._handle = 0
        self._queue = asyncio.PriorityQueue()
        self._order = itertools.count()

    async def run(self):
        sender = asyncio.create_task(self._send_worker())
        try:
            while True:
                try:
                    await self._session()
                except (serial.SerialException, OSError) as err:
                    log.error("radio link lost: %s", err)
                await asyncio.sleep(RADIO_REOPEN_S)
        finally:
            sender.cancel()

    async def wait_ready(self):
        await self._ready.wait()

    async def send(self, packet: bytes, priority: Priority = Priority.URGENT) -> TxResult:
        done = asyncio.get_running_loop().create_future()
        self._queue.put_nowait((priority, next(self._order), packet, done))
        return await done

    async def set_beacon(self, packet: bytes, interval_s: int):
        self._beacon = encode_frame(LinkMsg.SET_BEACON, LINK_BEACON_INFO.pack(interval_s) + packet)
        if self._ready.is_set():
            await self._write(self._beacon)

    async def _session(self):
        loop = asyncio.get_running_loop()
        self._serial = self._open()
        self._events = asyncio.Queue()
        loop.add_reader(self._serial.fileno(), self._read, FrameParser())
        try:
            while True:
                timeout = None if self._ready.is_set() else RADIO_READY_TIMEOUT_MS / 1000
                try:
                    event = await asyncio.wait_for(self._events.get(), timeout)
                except asyncio.TimeoutError:
                    log.warning("no READY from the radio, resetting it")
                    await self._reset()
                    continue
                if isinstance(event, Exception):
                    raise event
                await self._on_ready(event)
        finally:
            self._ready.clear()
            loop.remove_reader(self._serial.fileno())
            self._serial.close()

    # DTR and RTS stay off while opening, because many boards reset when the port opens.
    def _open(self) -> serial.Serial:
        port = serial.Serial()
        port.port = SERIAL_PORT
        port.baudrate = LINK_BAUD
        port.timeout = 0
        port.dtr = False
        port.rts = False
        port.open()
        return port

    async def _reset(self):
        self._serial.rts = True
        await asyncio.sleep(RADIO_RESET_PULSE_MS / 1000)
        self._serial.rts = False

    async def _on_ready(self, status: int):
        self._ready.clear()
        if status != ReadyStatus.OK:
            log.error("the radio could not start the SX1262, resetting it")
            await self._reset()
            return
        await self._write(encode_frame(LinkMsg.SET_POWER, bytes([RADIO_POWER_PRESET])))
        if self._beacon:
            await self._write(self._beacon)
        self._ready.set()
        log.info("radio ready")

    def _read(self, parser: FrameParser):
        try:
            data = self._serial.read(self._serial.in_waiting or 1)
        except (serial.SerialException, OSError) as err:
            asyncio.get_running_loop().remove_reader(self._serial.fileno())
            self._events.put_nowait(err)
            return
        for msg_type, payload in parser.feed(data):
            self._handle_frame(msg_type, payload)

    def _handle_frame(self, msg_type: int, payload: bytes):
        if msg_type == LinkMsg.READY and payload:
            self._events.put_nowait(payload[0])
        elif msg_type == LinkMsg.RX_PACKET and len(payload) > LINK_RX_INFO.size:
            rssi, snr = LINK_RX_INFO.unpack_from(payload)
            self._on_packet(payload[LINK_RX_INFO.size:], rssi, snr)
        elif msg_type == LinkMsg.TX_RESULT and len(payload) == LINK_TX_RESULT.size:
            handle, result = LINK_TX_RESULT.unpack(payload)
            if self._pending and self._pending[0] == handle and not self._pending[1].done():
                self._pending[1].set_result(TxResult(result))

    async def _write(self, frame: bytes):
        await asyncio.get_running_loop().run_in_executor(None, self._serial.write, frame)

    # One packet at a time, so the radio never queues airtime the server cannot account for.
    async def _send_worker(self):
        while True:
            _, _, packet, done = await self._queue.get()
            result = await self._transmit(packet)
            if not done.done():
                done.set_result(result)

    async def _transmit(self, packet: bytes) -> TxResult:
        if not self._ready.is_set():
            return TxResult.RADIO_ERROR
        self._handle = (self._handle + 1) & 0xFF
        outcome = asyncio.get_running_loop().create_future()
        self._pending = (self._handle, outcome)
        try:
            await self._write(encode_frame(LinkMsg.SEND_PACKET, LINK_SEND_INFO.pack(self._handle) + packet))
            return await asyncio.wait_for(outcome, TX_RESULT_TIMEOUT_MS / 1000)
        except (asyncio.TimeoutError, serial.SerialException, OSError):
            return TxResult.RADIO_ERROR
        finally:
            self._pending = None

# PROMPT: Off-Grid Radio Device Firmware (paste into any AI)

You are a senior embedded engineer. Write firmware for an off-grid multimedia radio made of TWO ESP chips. Build it in the phases listed at the end, ONE file per reply, and wait for me to say "next" before the next file.

## CODE RULES
1. Write like an experienced embedded developer writing by hand. Plain names, short functions, no decorative banners, no emoji, no generic filler.
2. Before keeping any line, ask: "Why does this line exist? What breaks if I delete it?" If nothing breaks, delete it.
3. No dead code, unused variables, unused includes, unused functions, or commented-out code.
4. No features, options, or abstractions that the spec does not ask for.
5. Comments only where the reason is not obvious. Never comment what the line plainly does.
6. Every function fully implemented. No TODO, placeholder, or pseudo-code.
7. No blocking delay() in the main flow. Use millis() or FreeRTOS tasks. Never block the UI while the radio works.
8. Handle failures that really happen (timeout, bad packet, full storage, lost link). No handling for things that cannot happen.
9. All pins, timings, sizes and keys live in config.h. No magic numbers elsewhere.
10. Before replying, re-read your code once, delete every line that fails rule 2, then output only the cleaned code.
11. Output format: file name, then code block. No explanations or summaries.

## TOOLCHAIN
PlatformIO, Arduino-ESP32 framework. Libraries: U8g2 (OLED), RadioLib (SX1262), TinyGPSPlus, Codec2, SparkFun ICM-20948, mbedTLS (built into ESP32), LittleFS. Do not use others unless necessary, and say why in one line.

## HARDWARE
- **Main ESP**: ESP32-S3FH4R2. Runs UI, buttons, audio, compass, crypto, storage, WiFi.
- **Radio ESP**: Heltec HT-CT62 (ESP32-C3 + SX1262). Runs LoRa, fragmenting, ACK/retry, beacons. It never touches GPS.
- Main and radio talk over UART (binary framed, below).
- OLED SSD1306 128x64 I2C (0x3C), ICM-20948 on the same I2C bus (with AK09916 magnetometer), MAX98357A I2S amp + speaker, I2S MEMS microphone on a connector socket, using a separate I2S port from the amp, 3 buttons (B1 up, B2 middle, B3 back), a battery with its own protection circuit (the firmware does not measure or show battery level). GPS module on the main ESP (J5, UART1).
- The OLED, GPS and microphone plug into connectors (J4, J5, J8). Pin numbers are in the PIN MAP below.
- The board also has BOOT and RESET buttons (SW1, SW2) that only flash and restart the ESPs. They are NOT part of the UI, never read them in the UI code.

## PIN MAP (from my schematic, put these in config.h exactly)
Main ESP32-S3:
- OLED I2C: SDA = GPIO7, SCL = GPIO8, address 0x3C. ICM-20948 on the same bus, address 0x69, INT1 = GPIO9. Run I2C at 100 kHz (a level shifter sits between the bus and the IMU).
- Buttons (active low, no external pull-ups, use INPUT_PULLUP and software debounce): B1 up = GPIO21, B2 middle = GPIO14, B3 back = GPIO10.
- Speaker amp MAX98357A on I2S port 0: DIN = GPIO4, BCLK = GPIO5, LRCLK = GPIO6. The amp is always on in hardware, there is no shutdown pin.
- Microphone on I2S port 1, receive only: BCLK = GPIO12, WS = GPIO11, DIN = GPIO13.
- GPS on UART1: RX = GPIO17, TX = GPIO18, 9600 baud. Keep `GPS_RX_PIN` and `GPS_TX_PIN` as separate defines so I can swap them.
- Radio link on UART2: TX = GPIO33, RX = GPIO34, 460800 baud. Radio enable pin = GPIO2 (high = on, pulse low = reset).
Radio ESP (HT-CT62, ESP32-C3): UART0 is the link to main: RX = GPIO20, TX = GPIO21, 460800 baud. The SX1262 pin mapping inside the module (NSS, SCK, MOSI, MISO, RESET, BUSY, DIO1) must be taken from the Heltec HT-CT62 datasheet or Heltec's board definition. Do NOT guess it. Put it in the radio config.h and tell me which source you used. Do not assume crystal versus TCXO, or how the RF switch is driven (DIO2 or separate pins). The schematic text I could read hints at a 32 MHz TCXO and an external RF switch, so take both from the datasheet and tell me what you found.

## DIVISION OF JOBS
**Main ESP does:** every screen, buttons, voice record (10 s max) + Codec2 encode/decode + playback, encryption and decryption, inbox storage, compass, reading the GPS module, GPS bearing and distance math, settings, WiFi/internet transport, deciding what to send.
**Radio ESP does:** LoRa TX/RX, splitting packets into LoRa-sized fragments and reassembling, ACK and retry, periodic beacon (payload supplied by main, including position), scanning for servers, listen-before-talk, applying the TX power preset. It never reads GPS and prints nothing on UART0 except link frames. It never sees plaintext, only ciphertext and headers.

## UART FRAME (main <-> radio)
`0xA5 | len(2, little endian) | type(1) | payload | crc16(2)`. Reject bad CRC. Resync on 0xA5. The ESP32-C3 prints boot text on UART0 before the firmware starts, so main must ignore every byte until it sees a valid frame, then wait for READY.

Main to radio: SEND_PACKET, SET_POWER(preset), SET_BEACON(payload with lat/lon, interval), SCAN_SERVERS, CONNECT(serverId), SLEEP.
Radio to main: READY (sent once after boot), RX_PACKET (data + rssi + snr), TX_RESULT(msgId, ok/fail), SERVER_LIST, LINK_STATE.

## LORA PACKET
Header (authenticated): `ver/type(1) | src(2) | dst(2) | msgId(2) | fragIdx(1) | fragTotal(1) | len(1)`, then payload, then 16-byte tag.
Types: BEACON (carries lat/lon), JOIN, JOIN_ACK, DEVLIST_REQ, DEVLIST, TEXT, VOICE_META, VOICE_FRAG, VOICE_REQ, VOICE_SLOT_FREE, ACK, NACK, POS, SOS.
Text gets one ACK. Voice gets one cumulative ACK after the last fragment, carrying a bitmap of received fragments (no ACK per fragment). Retry 3 times with backoff, then report failure to the UI.

## RADIO SETTINGS (India, 865 to 867 MHz, high-gain antenna fitted)
- Frequency 865.5 MHz (config.h), bandwidth 125 kHz only (never 250 or 500, the legal carrier limit is 200 kHz), spreading factor `NETWORK_SF` = 9 for the whole network, coding rate 4/5, preamble 8, CRC on, private sync word.
- Range presets change TX power only: Short +10, Medium +14, Long +17, Max +22 dBm.
- Antenna gain is `ANTENNA_GAIN_DBI` in config.h. Clamp the TX power so TX dBm plus antenna dBi minus 2 never exceeds 36 dBm.
- Listen before talk: channel activity detection before every transmit, random backoff if busy.
- Never transmit unless the radio reports it started correctly.

## VOICE COMPRESSION AND PACKETS
- Record 10 s max at 8 kHz mono, encode with Codec2 mode 700C (about 875 bytes per 10 s). Mode is a config option (1200 as the alternative).
- Cut the encoded note into very small fragments. Payload per VOICE_FRAG is `VOICE_FRAG_BYTES` in config.h (default 48), so a full note is about 19 short LoRa packets. VOICE_META is sent first with total fragments, total bytes and codec mode.
- Encrypt before fragmenting, so each fragment is part of one ciphertext and the radio ESP never sees audio.
- The receiver collects fragments by index and asks for missing ones by number (selective retry, never resend the whole note). If the note is still incomplete after the retry limit, discard it and report failure.
- Decode with Codec2 and play through the I2S amp.

## ENCRYPTION
- Each device creates an X25519 keypair at first boot, stored in NVS.
- On JOIN the device and server derive a **hop key** (device to server). Every packet is authenticated with it so the server can drop forged or junk packets.
- Message content is encrypted **end to end** between two devices: X25519 shared secret, HKDF, ChaCha20-Poly1305, with a fresh nonce per message. The server only forwards ciphertext.
- Reject replays using msgId window plus timestamp.

## AUTO-CONNECT
1. On boot, the radio ESP listens for server beacons and sends the list to main.
2. If a previously used server is heard, connect to it automatically. Otherwise the user picks in Send Msg.
3. The device beacons every 60 s (interval in config.h) with random jitter of about 20%, so the server can detect it. One beacon is about 0.3 s on air at SF9, so the interval must not be shortened without checking total airtime.
4. If the link drops, retry automatically and show the link icon state. If WiFi internet is on and connected, use it as the transport and fall back to LoRa when it drops.

## UI SPEC
Controls: B1 short = scroll up, wraps top to bottom. B2 short = select. B2 long (about 2 s) = send. B3 short = back one step (in text entry: delete last letter, back if empty). B3 long = Home. Same on every screen.
Status bar always: link strength, GPS fix, internet icon, unread count.

**Home (5):** Send Msg, Inbox, GPS, Compass, Settings.

**Send Msg:** Connect to server (list of servers heard, with signal) -> pick -> list of devices connected to that server -> pick -> Voice note or Text. Devices the server has flagged MISSING (flag arrives inside DEVLIST) show a MISSING tag plus last-seen time and last position; sending to them is still allowed and queues at the server.
- Voice: B2 starts recording, auto-stop at 10 s (B2 again stops early), countdown bar. After: B1 sends, B2 plays back, B3 discards. After send show popup "Msg sent!!" and return to the Voice/Text choice.
- Text: preset list ("I am safe", "I need help", "Come to my location", "On my way", "Low battery", "All good here"), last item "Custom message".
- Custom message: vertical list of characters (a b c d ... then digits, space, backspace, send). Top of screen shows the message line like `a| hello`. B1 scrolls the character list, B2 adds the highlighted character. B2 long sends. Popup "Msg sent!!".
- Incoming message popup: "Msg is here !!".

**Inbox:** top row toggles Text / Voice. Rows: date, time, sender, first words. Text opens fully. Voice rows show date/time and selecting one sends VOICE_REQ to the server and plays the note. Device stores ONE voice note only. If another arrives while the slot is full it is not accepted (server holds it) until the user deletes the stored one, then the device sends VOICE_SLOT_FREE. Text is never blocked by this.

**GPS:** the GPS module is always powered and always read, there is no ON/OFF toggle. List: server + every device. Select one: compass arrow pointing to it (using own GPS fix, the other device's last position from beacons, and the IMU heading) plus approximate distance. Show "no fix" cleanly.

**Compass:** heading in degrees + N/E/S/W, tilt-compensated, with a figure-8 calibration screen saved to flash.

**Settings:** (1) Screen timeout: 1, 3, 5, 7 min, Never. (2) LoRa range: Short, Medium, Long, Max, mapped to TX power only (+10, +14, +17, +22 dBm). The spreading factor is NOT changed here, it is fixed for the whole network. (3) Internet: WiFi scan, pick network, password entry with the letter-list keyboard, connect. (4) About device: ID, name, firmware version, frequency, free storage, uptime, GPS status.

**Extras to include:** delivery ticks (sent, at server, delivered, read), SOS (all three buttons held 3 s), clock set from GPS time, speaker volume, lock icon for encrypted messages, auto-delete oldest messages when storage is full.

## BUILD ORDER (one file per reply, wait for "next")
1. config.h
2. protocol.h (packet and UART structs, enums) and protocol.md (every field, byte order, constant and crypto step, so the Python server on the Raspberry Pi can match it exactly)
3. Radio firmware: lora.cpp (RadioLib wrapper), fragment.cpp, beacon.cpp, gps.cpp, uart_link.cpp, main.cpp
4. Main firmware: uart_link.cpp, crypto.cpp, storage.cpp, audio.cpp, compass.cpp, gpsnav.cpp, net.cpp (LoRa + WiFi transport), ui files (menu, textentry, popups, screens), settings.cpp, power.cpp, main.cpp

Start with step 1 now. Do not write anything else until I say "next".

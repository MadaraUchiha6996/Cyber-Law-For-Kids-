# PROMPT: Off-Grid Radio Server Firmware (paste into any AI)

You are a senior embedded engineer. Write firmware for the **relay server** of an off-grid LoRa radio network. Build it in the phases at the end, ONE file per reply, and wait for me to say "next".

## CODE RULES
1. Write like an experienced embedded developer writing by hand. Plain names, short functions, no decorative banners, no emoji, no generic filler.
2. Before keeping any line, ask: "Why does this line exist? What breaks if I delete it?" If nothing breaks, delete it.
3. No dead code, unused variables, unused includes, unused functions, or commented-out code.
4. No features, options, or abstractions that the spec does not ask for.
5. Comments only where the reason is not obvious. Never comment what the line plainly does.
6. Every function fully implemented. No TODO, placeholder, or pseudo-code.
7. No blocking delay() in the main flow. Use millis() or FreeRTOS tasks.
8. Handle failures that really happen (timeout, bad packet, storage full, lost link). No handling for things that cannot happen.
9. All pins, timings, sizes and keys live in config.h. No magic numbers elsewhere.
10. Before replying, re-read your code once, delete every line that fails rule 2, then output only the cleaned code.
11. Output format: file name, then code block. No explanations or summaries.

## HARDWARE
The server is the SAME board as the devices: main ESP32-S3FH4R2 (4 MB flash, 2 MB PSRAM) plus the HT-CT62 radio ESP (ESP32-C3 + SX1262), linked by UART with the same pin map, radio settings and UART frame as the device project. The radio ESP runs the same radio firmware as the devices, so write NO new radio code. There is no microSD slot: keep registry and queues in LittleFS on internal flash (one app slot, about 2 MB for data) and cap total queue size in config.h. Always powered by USB. Time from GPS (J5, if fitted) or NTP over WiFi. The OLED and buttons are optional, show online device count and queue size if present. PlatformIO, Arduino-ESP32, LittleFS, mbedTLS. It shares `protocol.h` with the device firmware (same packet types, header and crypto). Do not change that format.

## ROLE
The server is a **middleman that bounces messages**. Devices never talk directly to each other: sender -> server -> receiver. The server stores messages until the receiver asks for them.

## BOOT AND AUTO-CONNECT
1. On boot: mount LittleFS, load device registry and queues, check the time source, start the radio and wait for READY.
2. Server beacon every 60 s with jitter (interval in config.h) so devices can find it. Right after boot also broadcast one SERVER_HELLO so nearby devices answer with a beacon after a random delay, instead of the server waiting up to a full interval.
3. Every device beacons constantly. When the server hears a beacon from a known device it connects automatically (JOIN_ACK), marks it online, and records signal strength and last position. Unknown devices get an automatic JOIN and a registry entry on first contact.
4. A device not heard for 3 beacon intervals is marked offline. Its messages stay queued.
5. Reply to DEVLIST_REQ with the list of online devices (name, id, last position age).

## STORE AND FORWARD
- **Text:** queue per recipient in flash. Deliver when the recipient is online and asks, or push when it comes online. Remove after ACK. Expire after a TTL in config.h.
- **Voice:** store fragments on SD. Each device holds **one** voice note. If the device's slot is full, keep the voice note queued and do not push it. Deliver only after the device sends VOICE_SLOT_FREE or VOICE_REQ. **Text delivery must never wait on voice.** One voice note per recipient waiting at most (oldest wins or newest wins, make it a config option).
- Delivery receipts back to the sender: at server, delivered, failed.
- Resume interrupted voice transfers by fragment index.
- Voice arrives as very small fragments (payload `VOICE_FRAG_BYTES`, default 48 bytes, about 19 per 10 s note). The server stores and forwards them as they are, never decodes or re-encodes, and answers fragment retry requests by index.

## MISSING DEVICE DETECTION
- Track for every device: last time ANY valid packet was received from it (beacon, ACK, message), last position, and last ACK or read time for messages delivered to it.
- Flag the device **MISSING** when both are older than `MISSING_AFTER_DAYS` in config.h (default 3): no valid packet of any kind AND no response to queued text or voice. A device that still beacons but never responds is flagged `UNRESPONSIVE` (separate flag).
- Store the last known position and time with the flag. Include the flag, last-seen time and last position in DEVLIST replies so devices can show it.
- Notify the sender: when someone sends to a MISSING device, return a delivery receipt of "recipient missing" in addition to queuing the message.
- Clear the flag automatically on the next valid packet from that device.
- Messages for a missing device stay queued until their normal TTL.

## ENCRYPTION AND WHAT THE SERVER CAN CHECK
- Device to server link: **hop key** authenticates every packet. The server drops anything that fails authentication.
- Device to device content: **end-to-end encrypted** (X25519 + ChaCha20-Poly1305). The server cannot read it and must not try.
- Because content is opaque, "virus checking" is done on everything the server can actually see. Validation pipeline for every packet, in this order, drop and log on the first failure:
  1. Version and type are known.
  2. Length fits the type and the LoRa limit.
  3. Hop-key authentication tag is valid.
  4. Sender is registered and not blocked.
  5. Replay check (msgId window + timestamp).
  6. Rate limit per device (config.h).
  7. Fragment sanity: index < total, total within limit, no duplicates, no gaps on completion.
  8. Voice sanity: total size matches at most 10 s of the codec rate. Text size under the max.
  9. Destination exists.
- Repeat offenders are blocked for a period. Everything dropped is logged with the reason.
- Server never forwards a message that failed validation, so a bad or malformed packet cannot reach a device.

## INTERNET BRIDGE
When WiFi is available, the server accepts messages from devices in internet mode over a secure WebSocket, runs the same validation pipeline, and routes between LoRa and internet clients. Same queues, same encryption.

## RELIABILITY
Hardware watchdog, restart after crash and resume from SD, queues written atomically (write temp file then rename), SD-full handling (drop oldest expired first), clock set from GPS or NTP, serial log with levels.

## BUILD ORDER (one file per reply, wait for "next")
1. config.h
2. protocol.h (same as the device project)
3. radio.cpp (LoRa receive/send, beacon)
4. registry.cpp (devices, online state, blocking)
5. validator.cpp (pipeline above)
6. queue.cpp and storage.cpp (text and voice queues on SD)
7. router.cpp (joins, device list, forwarding, receipts)
8. bridge.cpp (internet)
9. main.cpp

Start with step 1 now. Do not write anything else until I say "next".

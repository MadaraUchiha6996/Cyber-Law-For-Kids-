# Protocol

This file is the contract between the handheld firmware, the radio firmware and the Pi server.
`protocol.h` and `config.h` hold the same numbers in code form. If they disagree with this file, fix the code.

## 1. Conventions

- All multi-byte integers are little endian. Python: always use `struct` formats starting with `<`.
- Positions are signed 32-bit degrees times 1e7.
- Names are 12 ASCII bytes, padded with zero bytes. A 12-character name has no terminator.
- Message id 0 is reserved for packets without a tag (beacon, hello, join). Counters start at 1.
- Id 0x0000 (`ID_NONE`) is invalid. Id 0xFFFF (`ID_BROADCAST`) means every device.

## 2. UART link (host <-> radio)

The host is the handheld's main ESP or the Pi. The radio is the HT-CT62 or the Heltec V3. 460800 baud, 8N1.

### 2.1 Frame

```
0xA5 | len (2) | type (1) | payload (len bytes) | crc16 (2)
```

- `len` counts the payload only. Maximum `LINK_MAX_PAYLOAD` (288).
- CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflection, no final xor) over `len`, `type` and payload.
  The CRC is sent low byte first. Check value: the ASCII string `123456789` gives 0x29B1.
- The radio chip prints boot text on the same wire. A receiver ignores bytes until 0xA5, then reads the
  frame. On a bad length, a bad CRC, or a frame that is not finished within `LINK_FRAME_TIMEOUT_MS`,
  it drops the 0xA5 it used and searches again from the next byte.

### 2.2 Messages

| Type | Name | From | Payload |
|---|---|---|---|
| 0x01 | SEND_PACKET | host | `handle` (1), then one finished LoRa packet (10 to 255 bytes) |
| 0x02 | SET_POWER | host | preset (1): 0 short, 1 medium, 2 long, 3 max |
| 0x03 | SET_BEACON | host | `interval_s` (2), then one finished beacon packet. Interval 0 stops beacons. |
| 0x81 | READY | radio | status (1): 0 ok, 1 SX1262 failed to start |
| 0x82 | RX_PACKET | radio | `rssi` (int8, dBm), `snr` (int8, dB), then the LoRa packet as received |
| 0x83 | TX_RESULT | radio | `handle` (1), result (1): 0 sent, 1 channel busy, 2 radio error |

### 2.3 Radio behaviour

- After boot the radio sends READY once. The host sends nothing before READY. If READY does not arrive within
  `RADIO_READY_TIMEOUT_MS`, the host pulses the radio reset (EN low for `RADIO_RESET_PULSE_MS`) and waits again.
  Every READY after the first means the radio restarted, so the host sends SET_POWER and SET_BEACON again.
- Radio settings are the ones in `config.h`. The radio sets DIO2 as the RF switch control. Until the first
  SET_POWER it uses the short preset.
- TX power in dBm is the preset's value from `config.h`, lowered if needed so that
  `power + ANTENNA_GAIN_DBI - FEEDLINE_LOSS_DB <= EIRP_LIMIT_DBM`.
- The radio receives all the time except while transmitting. Every received packet with a good LoRa CRC and a
  length of at least 10 bytes goes up as RX_PACKET. The radio does not look inside.
- SEND_PACKET: the radio does listen-before-talk. It runs channel activity detection. If the channel is busy it waits a
  random time between `LBT_BACKOFF_MIN_MS` and `LBT_BACKOFF_MAX_MS` and tries again, up to `LBT_MAX_ATTEMPTS`
  times, then answers TX_RESULT 1. Otherwise it transmits and answers TX_RESULT 0. The host sends the next
  SEND_PACKET only after the TX_RESULT of the previous one. A SEND_PACKET that arrives while the radio is busy,
  or after a failed start, or shorter than 10 bytes, gets TX_RESULT 2.
- Beacons: the radio sends the stored beacon packet every `interval_s` seconds, plus or minus a random
  `BEACON_JITTER_PCT` percent. The first one goes out after a random delay of up to that same percent of the
  interval. The beacon uses listen-before-talk. If the channel stays busy that beacon is skipped. Beacons produce no TX_RESULT.
  A new SET_BEACON replaces the stored packet and interval without restarting the schedule.

## 3. LoRa packet

```
header (10) | payload (len) | tag (16, only if the type has one)
```

### 3.1 Header

| Offset | Size | Field |
|---|---|---|
| 0 | 1 | version in the high nibble (1), type in the low nibble |
| 1 | 2 | `src` sender id |
| 3 | 2 | `dst` destination id |
| 5 | 2 | `msg_id` |
| 7 | 1 | `frag_idx` |
| 8 | 1 | `frag_total` |
| 9 | 1 | `len` payload bytes |

`src` and `dst` are the end points. The server forwards a packet with `src` and `dst` unchanged but gives it a
new `msg_id` and a new tag for the next hop.
Total packet length must equal 10 + `len` (+ 16 with a tag) and must not exceed `LORA_MAX_PAYLOAD` (255).
Longest payload is 229.

### 3.2 Types

| Id | Type | Direction | Tag | Payload | Answered by |
|---|---|---|---|---|---|
| 1 | BEACON | device or server, to all | no | 21 | none |
| 2 | SERVER_HELLO | server, to all or one device | no | 0 | JOIN |
| 3 | JOIN | device to server | no | 52 | JOIN_ACK |
| 4 | JOIN_ACK | server to device | yes | 40 | none |
| 5 | DEVLIST_REQ | device to server | yes | 0 | DEVLIST |
| 6 | DEVLIST | server to device | yes | 59 x k, k = 1 to 3 | none |
| 7 | TEXT | device to server to device | yes | 29 to 128 | ACK |
| 8 | VOICE_META | device to server to device | yes | 3 | ACK |
| 9 | VOICE_FRAG | device to server to device | yes | 1 to 48 | ACK with bitmap after the last fragment |
| 10 | VOICE_REQ | device to server | yes | 2 | the fragments |
| 11 | VOICE_SLOT_FREE | device to server | yes | 0 | ACK |
| 12 | ACK | either way | yes | 2, or 2 + 3 for voice | none |
| 13 | RECEIPT | server to device, device to server | yes | 3 | ACK |
| 14 | SOS | device to server to devices | yes | 8 | ACK |

For BEACON, SERVER_HELLO and JOIN: `msg_id` is 0, `frag_idx` is 0, `frag_total` is 1.
Every other packet that is not part of a fragment series has `frag_idx` 0 and `frag_total` 1.

### 3.3 Payload layouts (Python `struct` formats)

| Payload | Format | Bytes | Fields |
|---|---|---|---|
| header | `<BHHHBBB` | 10 | ver/type, src, dst, msg_id, frag_idx, frag_total, len |
| BEACON | `<Bii12s` | 21 | flags (0x01 server, 0x02 no fix), lat, lon, name |
| JOIN | `<32s8s12s` | 52 | public key, device nonce, name |
| JOIN_ACK | `<32s8s` | 40 | server public key, server nonce |
| DEVLIST entry | `<HBiiI12s32s` | 59 | id, flags, lat, lon, age_s, name, public key |
| VOICE_META | `<HB` | 3 | blob_bytes, codec (0 = 700C, 1 = 1200) |
| VOICE_REQ | `<H` | 2 | voice id (see 6.4) |
| ACK | `<H` + bitmap | 2 or 5 | acked msg_id, then 3 bytes bitmap (voice only) |
| RECEIPT | `<HB` | 3 | msg_id, status |
| SOS | `<ii` | 8 | lat, lon |
| link RX_PACKET info | `<bb` | 2 | rssi, snr |
| link TX_RESULT | `<BB` | 2 | handle, result |
| link SET_BEACON info | `<H` | 2 | interval_s |

DEVLIST entry flags: 0x01 online, 0x02 missing, 0x04 unresponsive, 0x08 no fix.
`age_s` is the seconds since the server last received any valid packet from that device.
`lat` and `lon` are the last known position and are valid unless the no-fix flag is set.
RECEIPT status: 1 delivered, 2 read, 3 recipient missing, 4 failed (no such device), 5 failed (expired),
6 failed (refused).
The ACK bitmap has bit n set (byte n/8, bit n%8, least significant bit first) when fragment n arrived.

## 4. Identity and keys

- Every device and the server make an X25519 key pair at first boot and keep it.
- The id is the first two bytes of SHA-256 of the 32-byte public key, read as a little endian number.
  If the result is 0x0000 or 0xFFFF the key pair is thrown away and made again.
- The server learns a device's public key from its first JOIN and remembers it. A later JOIN for that id
  with a different key is dropped. The device remembers the server's public key from the first JOIN_ACK and
  refuses a different one later.

## 5. Session (JOIN)

1. The device hears a server beacon (or SERVER_HELLO) from the server it wants and sends JOIN with a fresh random
   8-byte device nonce. After a SERVER_HELLO it first waits a random time up to `HELLO_REPLY_MAX_MS`.
2. The server checks that the id in `src` matches the public key, creates a registry entry if the id is new,
   makes a random 8-byte server nonce, and replaces any older session of that device.
3. Both sides compute the hop key:

```
shared  = X25519(own private key, other public key)
hop_key = HKDF-SHA256(ikm = shared, salt = device_nonce | server_nonce, info = "offgrid-hop-v1", length = 32)
```

4. The server answers JOIN_ACK, which already carries a hop tag. The device checks the tag. That is
   how it knows the server holds the pinned key. Message counters on the device side start at 1.
5. A device with an empty voice slot sends VOICE_SLOT_FREE right after every successful JOIN.
6. If no JOIN_ACK arrives within `ACK_TIMEOUT_MS`, JOIN is sent again, up to `SEND_RETRY_MAX` retries.
7. When the server hears a beacon from a registered device that has no live session, it sends that device a
   SERVER_HELLO, at most once per `BEACON_INTERVAL_S` per device.
8. A device that misses `SERVER_LOST_BEACONS` server beacons in a row treats the session as lost and joins again
   when it hears the server again. A sender also joins again before its counter reaches `MSG_ID_LIMIT`.

The server keeps one message counter per device that does not reset at a new session. It uses that counter for
every packet it sends to that device, including forwarded ones. When the counter reaches `MSG_ID_LIMIT` it goes
back to 1 and the session is dropped so the device must join again.

## 6. Hop tag

Every packet except BEACON, SERVER_HELLO and JOIN ends with a 16-byte tag.

```
tag = ChaCha20-Poly1305 (RFC 8439) with key = hop_key, nonce = hop nonce,
      plaintext = empty, associated data = header (10 bytes) | payload
```

The payload stays readable. The tag only proves the packet came from a holder of the hop key and was not changed.

Hop nonce, 12 bytes: `src` (2) | `msg_id` (2) | `frag_idx` (1) | type (1) | six zero bytes.

A retransmission is the identical packet, so it reuses the nonce safely. A new packet always gets a new
`msg_id`, even an ACK that repeats an earlier ACK. Fragments of one voice note share `msg_id` and differ in `frag_idx`.

## 7. End-to-end encryption (TEXT and voice)

```
shared = X25519(own private key, peer public key)
key    = HKDF-SHA256(ikm = shared, salt = low_id (2) | high_id (2), info = "offgrid-e2e-v1", length = 32)
```

`low_id` and `high_id` are the two device ids in numeric order. Each side gets the peer's public key from DEVLIST.

- Blob = `nonce` (12 random bytes) | ciphertext | tag (16), using ChaCha20-Poly1305 with associated data
  `src` (2) | `dst` (2) of the original sender and recipient. The server cannot decrypt it and cannot re-address it.
- TEXT payload is the blob. Plaintext is 1 to `TEXT_MAX_BYTES` (100) ASCII bytes with no terminator.
- Voice: plaintext is the Codec2 bit stream. Each frame contributes its first `VOICE_FRAME_BITS` bits,
  most significant bit first, with no gaps between frames, padded with zero bits to a whole byte.
  Frame count = floor(plaintext bytes x 8 / `VOICE_FRAME_BITS`). The blob is cut into
  pieces of `VOICE_FRAG_BYTES` (48), the last one shorter.
  `blob_bytes` in VOICE_META is the blob length. A full 10 s note is 875 + 28 = 903 bytes, which is 19 fragments.

## 8. Reliability rules

- Needs an ACK: TEXT, VOICE_META, VOICE_SLOT_FREE, RECEIPT, SOS, and a voice transfer (once, after its last fragment).
  Nothing else is acknowledged.
- ACK (payload 2 bytes): the receiver sends a new ACK packet with a fresh `msg_id` and the acked `msg_id` in the payload.
- The sender waits `ACK_TIMEOUT_MS` (`VOICE_ACK_TIMEOUT_MS` after a voice transfer), then waits
  `RETRY_BACKOFF_MS` doubled for every earlier retry plus a random 0 to `RETRY_BACKOFF_MS`, then sends the identical
  packet again. After `SEND_RETRY_MAX` retries it reports failure.
- Replay window: per session and per direction, the receiver keeps the highest `msg_id` seen and a 64-bit mask of
  the last `REPLAY_WINDOW` ids. An id above the highest is accepted. An id at or below highest minus 64, or
  already marked, is a duplicate. A duplicate is not processed again, but if the type needs an ACK the receiver
  sends the ACK again. The window belongs to the session peer, not to the `src` field, because the server
  numbers forwarded packets with its own counter.
- VOICE_FRAG is exempt from the window check once its transfer is open (see section 9). Fragment duplicates are
  ignored through the fragment bitmap.
- An incomplete voice transfer is dropped after `REASSEMBLY_TIMEOUT_MS` without a new fragment.

## 9. Flows

### 9.1 Beacons and hello

- Devices and servers send BEACON (dst 0xFFFF) every `BEACON_INTERVAL_S` with jitter. A device lists
  servers from the beacons with the server flag, with the RSSI the radio reported.
- A server sends SERVER_HELLO to all when it starts.
- The server marks a device offline after 3 intervals without a valid packet. Its messages stay queued.

### 9.2 Device list

Device sends DEVLIST_REQ. The server answers with DEVLIST packets: same `msg_id`, `frag_idx` 0 to total - 1,
up to 3 entries each. It lists every registered device except the asker that is online, missing or unresponsive.
The device repeats the request if the list is not complete after `ACK_TIMEOUT_MS`. It stores each entry's public key.

### 9.3 Text

1. Sender builds the blob, sends TEXT (dst = recipient, `msg_id` M) to the server, and waits for ACK. The ACK is the
   "at server" tick.
2. The server drops it as invalid if the checks in section 10 fail. If valid but not acceptable (recipient is the
   sender, unknown recipient, queue full) it sends the ACK and then RECEIPT failed (reason 4 or 6 for
   those, 5 when it expires). If the recipient is flagged missing it also sends RECEIPT 3, and keeps the message.
3. When the recipient has a live session the server sends the TEXT on (same `src` and `dst`, new `msg_id` D from its
   counter) and waits for ACK. After the ACK it sends RECEIPT delivered with the sender's M.
4. When the recipient reads the message, its device sends RECEIPT read (msg_id = D) to the server, which maps D back to M and
   sends RECEIPT read (msg_id = M) to the sender.

The server keeps D and M together for each delivery until the message expires.

### 9.4 Voice from sender to server

1. Sender sends VOICE_META (`msg_id` M, `frag_total` n) and waits for ACK.
2. Sender sends VOICE_FRAG 0 to n - 1 with the same M, one at a time, no ACK per fragment.
3. After the last fragment the server sends ACK (M) with the bitmap. The sender sends again every fragment
   whose bit is clear, then waits for the ACK again. If no ACK arrives, the sender sends the last fragment again.
   Rounds and waits follow section 8. A full bitmap ends the transfer.
4. The ACK with a full bitmap is the "at server" tick.

### 9.5 Voice from server to recipient (one slot per device)

- The server tracks one slot per device: free or full. VOICE_SLOT_FREE (the user deleted the note, or the device
  joined with an empty slot) makes it free.
- If the slot is free and a voice note waits, the server announces it: VOICE_META (src = original sender,
  `msg_id` D1, same `blob_bytes` and codec) and waits for ACK. The slot is now full. Only one note is announced.
  Others wait, the oldest or the newest wins by a server setting, and text is never held back.
- The inbox shows the announced note. D1 is its voice id.
- When the user picks it, the device sends VOICE_REQ (payload D1). The server sends VOICE_FRAG 0 to n - 1 with
  a new `msg_id` D2, `frag_total` n. No VOICE_META is repeated. The device opens the transfer from the first fragment
  that follows its request, if D2 is newer than the highest id it has seen.
- The device sends ACK (D2, bitmap) after the last fragment, or when `ACK_TIMEOUT_MS` passes with the
  transfer incomplete. The server sends again every fragment whose bit is clear, up to `SEND_RETRY_MAX` rounds.
  A repeated VOICE_REQ while a transfer is running is ignored. If no fragment arrives within `VOICE_ACK_TIMEOUT_MS`
  the device sends VOICE_REQ again, up to `SEND_RETRY_MAX` times.
- A full bitmap makes the server send RECEIPT delivered to the sender and delete its copy.
- When the user plays the note, the device sends RECEIPT read (msg_id = D1).

### 9.6 SOS

The device sends SOS with dst 0xFFFF. The server ACKs, then sends an SOS (src unchanged, dst each other online
device, new `msg_id`) to every online device except the sender, with retries. There is no receipt.

## 10. What the server checks, in order

Drop and log on the first failure. Nothing is sent back for a dropped packet.

1. Version is 1 and the type is 1 to 14 and allowed in that direction (section 3.2).
2. Packet length equals 10 + `len` + tag, and `len` matches the payload size for the type.
3. Tag valid under the sender's hop key (not for BEACON, SERVER_HELLO, JOIN). A JOIN also needs `src` to match its key.
4. Sender is registered and not blocked. JOIN and BEACON may come from a new device.
5. Replay window (section 8).
6. Rate limit per device.
7. Fragments: index below total, total at most 19, no duplicate, nothing missing on completion.
   VOICE_FRAG needs an open transfer, opened by its VOICE_META.
8. Voice size: `blob_bytes` between 29 and 903, equal to the sum of the fragment lengths, and `frag_total` equal to
   ceil(`blob_bytes` / 48). Codec equals the server's codec.
9. Destination exists, and is not the sender.

## 11. Internet transport

A binary WebSocket message holds exactly one packet. Session, tags, keys and every rule above are unchanged.
The device sends JOIN first. Beacons and SERVER_HELLO are not used. TLS protects the connection, the hop tag still
protects every packet.

## 12. Numbers the Pi must match

| Name | Value |
|---|---|
| `LORA_MAX_PAYLOAD` | 255 |
| header, tag, longest payload | 10, 16, 229 |
| `VOICE_FRAG_BYTES`, `VOICE_MAX_BYTES` | 48, 875 (700C) |
| largest blob, most fragments, bitmap | 903, 19, 3 bytes |
| `TEXT_MAX_BYTES` | 100 |
| DEVLIST entries per packet | 3 |
| `REPLAY_WINDOW`, `MSG_ID_LIMIT` | 64, 0xFF00 |
| `BEACON_INTERVAL_S`, `BEACON_JITTER_PCT` | 60, 20 |
| `ACK_TIMEOUT_MS`, `VOICE_ACK_TIMEOUT_MS` | 3000, 6000 |
| `SEND_RETRY_MAX`, `RETRY_BACKOFF_MS` | 3, 1500 |
| `REASSEMBLY_TIMEOUT_MS` | 30000 |

## 13. Known limits

- The first JOIN_ACK a device accepts fixes the server's key. An attacker present at that moment could pose as the server.
- Senders trust the public keys the server lists in DEVLIST. A hacked server could swap a key and read messages.
  The server cannot read messages while it behaves.
- Ids are 16 bits. Two devices with the same id cannot both register. The second one has to make a new key.
- Beacons, hello and join are not authenticated, so someone nearby can fake a beacon or a hello. The worst effect is extra joins.

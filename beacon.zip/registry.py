import time
from collections import OrderedDict, deque
from dataclasses import dataclass

import config
import db
from protocol import REPLAY_WINDOW, DevFlag, device_id

# Fragments and retries of one voice note share a msg_id, so the window is wider than REPLAY_WINDOW.
SEEN_KEYS_MAX = 4 * REPLAY_WINDOW
ONLINE_AFTER_S = config.DEVICE_LOST_BEACONS * config.BEACON_INTERVAL_S * (1 + config.BEACON_JITTER_PCT / 100)
MISSING_AFTER_S = config.MISSING_AFTER_DAYS * 86400


@dataclass
class Device:
    id: int
    name: str
    public_key: bytes
    hop_key: bytes
    lat: int
    lon: int
    last_seen: float
    last_response: float
    voice_busy: bool
    no_fix: bool = False
    # When the server first sent this device something it has not answered since. 0 if nothing waits.
    pending_since: float = 0.0


_devices: dict[int, Device] = {}
_seen_keys: dict[int, OrderedDict] = {}
_rate: dict[int, deque] = {}
_drops: dict[int, int] = {}
_blocked: dict[int, float] = {}


def load() -> None:
    for row in db.load_devices():
        _devices[row["id"]] = Device(row["id"], row["name"], row["public_key"], row["hop_key"],
                                     row["lat"], row["lon"], row["last_seen"], row["last_response"],
                                     bool(row["voice_busy"]))
        if row["blocked_until"] > time.time():
            _blocked[row["id"]] = row["blocked_until"]


def get(dev_id: int) -> Device | None:
    return _devices.get(dev_id)


def all_devices() -> list[Device]:
    return list(_devices.values())


# Two different keys can hash to the same 16 bit id. The second one is refused, not allowed to take over.
def add(public_key: bytes, name: str, hop_key: bytes) -> Device:
    dev_id = device_id(public_key)
    old = _devices.get(dev_id)
    if old and old.public_key != public_key:
        raise ValueError("device id already taken by another key")
    db.save_device(dev_id, name, public_key, hop_key)
    now = time.time()
    if old:
        old.name, old.hop_key, old.last_seen = name, hop_key, now
        _seen_keys.pop(dev_id, None)
        return old
    dev = Device(dev_id, name, public_key, hop_key, 0, 0, now, now, False)
    _devices[dev_id] = dev
    return dev


def heard(dev_id: int, lat: int | None = None, lon: int | None = None, no_fix: bool = False) -> None:
    dev = _devices.get(dev_id)
    if not dev:
        return
    dev.last_seen = time.time()
    if lat is not None and not no_fix:
        dev.lat, dev.lon = lat, lon
    dev.no_fix = no_fix
    db.touch_device(dev_id, dev.lat, dev.lon)


# Any packet except a beacon proves the device is listening and talking, so it counts as a response.
def responded(dev_id: int) -> None:
    dev = _devices.get(dev_id)
    if dev:
        dev.last_response = time.time()
        dev.pending_since = 0.0
        db.mark_response(dev_id)


def sent_to(dev_id: int) -> None:
    dev = _devices.get(dev_id)
    if dev and not dev.pending_since:
        dev.pending_since = time.time()


def set_voice_busy(dev_id: int, busy: bool) -> None:
    dev = _devices.get(dev_id)
    if dev:
        dev.voice_busy = busy
        db.set_voice_busy(dev_id, busy)


def flags(dev: Device) -> DevFlag:
    now = time.time()
    result = DevFlag(0)
    online = now - dev.last_seen <= ONLINE_AFTER_S
    if online:
        result |= DevFlag.ONLINE
    # It keeps beaconing but has not answered anything the server sent for days.
    if online and dev.pending_since and now - dev.pending_since > MISSING_AFTER_S:
        result |= DevFlag.UNRESPONSIVE | DevFlag.MISSING
    if now - dev.last_seen > MISSING_AFTER_S:
        result |= DevFlag.MISSING
    if dev.no_fix:
        result |= DevFlag.NO_FIX
    return result


def is_missing(dev: Device) -> bool:
    return bool(flags(dev) & DevFlag.MISSING)


def is_blocked(src: int) -> bool:
    until = _blocked.get(src)
    if until and until <= time.time():
        del _blocked[src]
        return False
    return until is not None


def rate_ok(src: int) -> bool:
    now = time.time()
    window = _rate.setdefault(src, deque())
    while window and now - window[0] > config.RATE_LIMIT_WINDOW_S:
        window.popleft()
    if len(window) >= config.RATE_LIMIT_PACKETS:
        return False
    window.append(now)
    return True


# Returns True when this packet was already seen from this device, so a retry is not handled twice.
def is_duplicate(dev_id: int, key: tuple) -> bool:
    seen = _seen_keys.setdefault(dev_id, OrderedDict())
    if key in seen:
        return True
    seen[key] = None
    if len(seen) > SEEN_KEYS_MAX:
        seen.popitem(last=False)
    return False


def good(src: int) -> None:
    _drops.pop(src, None)


# Called for every packet dropped for being bad. Too many in a row blocks the sender for a while.
def strike(src: int) -> None:
    _drops[src] = _drops.get(src, 0) + 1
    if _drops[src] >= config.BLOCK_AFTER_DROPS:
        until = time.time() + config.BLOCK_SECONDS
        _blocked[src] = until
        _drops.pop(src)
        if src in _devices:
            db.set_blocked(src, until)
